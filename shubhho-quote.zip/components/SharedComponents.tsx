import React, { useState, useEffect } from 'react';
import { Quotation, QuotationStatus } from '../types';
import { X, Star, Frown, Clock, CheckCircle, FileText, XCircle, AlertCircle, Eye, EyeOff } from 'lucide-react';

interface FeedbackPopupProps {
    status: QuotationStatus;
    onClose: () => void;
}

export const FeedbackPopup: React.FC<FeedbackPopupProps> = ({ status, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(onClose, 2000);
        return () => clearTimeout(timer);
    }, [onClose]);

    const feedbackConfig = {
        [QuotationStatus.SALE]: { icon: <Star className="h-16 w-16 text-brand-yellow-400 animate-pulse" />, message: "Sale Confirmed!" },
        [QuotationStatus.CANCEL]: { icon: <Frown className="h-16 w-16 text-red-500" />, message: "Quotation Cancelled" },
        [QuotationStatus.WALK_OUT]: { icon: <Frown className="h-16 w-16 text-orange-500" />, message: "Walk-out Saved" },
        [QuotationStatus.DRAFT]: { icon: <Clock className="h-16 w-16 text-blue-500" />, message: "Draft Saved" },
    };

    const currentFeedback = feedbackConfig[status];

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4">
            <div className="bg-brand-indigo-800 border-2 border-brand-yellow-500 rounded-lg shadow-xl w-full max-w-sm p-8 text-center flex flex-col items-center space-y-4">
                {currentFeedback.icon}
                <p className="text-xl font-semibold text-white">{currentFeedback.message}</p>
            </div>
        </div>
    );
};

interface CancelModalProps {
    onClose: () => void;
    onSubmit: (reason: { category: string; subCategory: string }) => void;
}

export const CancelModal: React.FC<CancelModalProps> = ({ onClose, onSubmit }) => {
    const cancelReasons = {
        'Pricing-Related': ['Product price too high', 'Found cheaper options elsewhere', 'Waiting for discount/offer/sale'],
        'Product Range / Stock Availability': ['Limited variety/styles', 'Desired product/color/size not available', 'Stock not refreshed/frequent repeats', 'Collection not good'],
        'Fit & Comfort Issues': ['Improper fitting', 'Size not available', 'Material uncomfortable'],
        'Purchase Decision Pending': ['Just browsing/looking', 'Visiting other shops for comparison', 'Will come with family/friend later', 'Need time to decide'],
        'Service/Experience Feedback': ['Delay in assistance', "Didn't feel welcomed or attended", 'Store ambiance/layout confusing', 'Billing/waiting time issues'],
        'Others / Miscellaneous': ['Already purchased elsewhere', 'Payment issues (card declined, no UPI, etc.)', 'Emergency call/left suddenly', 'Personal reasons not disclosed']
    };
    const [category, setCategory] = useState(Object.keys(cancelReasons)[0]);
    const [subCategory, setSubCategory] = useState(cancelReasons[category][0]);

    useEffect(() => {
        setSubCategory(cancelReasons[category][0]);
    }, [category]);

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
            <div className="bg-brand-indigo-800 border-2 border-brand-yellow-500 rounded-lg shadow-xl w-full max-w-md p-6 relative">
                <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-white transition-colors"><X size={24} /></button>
                <h3 className="text-lg font-semibold text-white mb-4">Select Reason for Cancellation</h3>
                <div className="space-y-4">
                    <div>
                        <label className="text-sm font-medium text-gray-300">Category</label>
                        <select value={category} onChange={(e) => setCategory(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-brand-indigo-700 border-brand-indigo-600 text-white focus:outline-none focus:ring-brand-yellow-500 sm:text-sm rounded-md">
                            {Object.keys(cancelReasons).map(cat => <option key={cat} value={cat} className="bg-white text-brand-indigo-800">{cat}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-300">Sub-category</label>
                        <select value={subCategory} onChange={(e) => setSubCategory(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-brand-indigo-700 border-brand-indigo-600 text-white focus:outline-none focus:ring-brand-yellow-500 sm:text-sm rounded-md">
                            {cancelReasons[category].map(sub => <option key={sub} value={sub} className="bg-white text-brand-indigo-800">{sub}</option>)}
                        </select>
                    </div>
                </div>
                <div className="mt-6 flex justify-end">
                    <button onClick={() => onSubmit({ category, subCategory })} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-brand-indigo-900 bg-brand-yellow-500 hover:bg-brand-yellow-400 transition-colors">Submit</button>
                </div>
            </div>
        </div>
    );
};

interface ConfirmationDialogProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    message: string;
}

export const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({ isOpen, onClose, onConfirm, title, message }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-sm">
                <h3 className="text-lg font-bold text-gray-800">{title}</h3>
                <p className="my-4 text-gray-600">{message}</p>
                <div className="flex justify-end space-x-4">
                    <button onClick={onClose} className="px-4 py-2 rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300 transition-colors">Cancel</button>
                    <button onClick={onConfirm} className="px-4 py-2 rounded-md text-white bg-red-600 hover:bg-red-700 transition-colors">Confirm</button>
                </div>
            </div>
        </div>
    );
};

export const StatusIndicator: React.FC<{ status: QuotationStatus }> = ({ status }) => {
    const styles = {
        [QuotationStatus.DRAFT]: { icon: <FileText size={16} />, color: 'blue-500', text: 'Draft' },
        [QuotationStatus.SALE]: { icon: <CheckCircle size={16} />, color: 'green-500', text: 'Sale' },
        [QuotationStatus.CANCEL]: { icon: <XCircle size={16} />, color: 'red-500', text: 'Cancel' },
        [QuotationStatus.WALK_OUT]: { icon: <AlertCircle size={16} />, color: 'orange-500', text: 'Walk-out' },
    };
    const style = styles[status] || { icon: <FileText size={16} />, color: 'gray-500', text: status };
    return (<div className={`flex items-center space-x-2 text-${style.color}`}><span className={`text-${style.color}`}>{style.icon}</span><span>{style.text}</span></div>);
};

export const PasswordInput: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => {
    const [showPassword, setShowPassword] = useState(false);
    const { className, ...rest } = props;

    return (
        <div className={`relative ${className || ''}`}>
            <input
                {...rest}
                type={showPassword ? 'text' : 'password'}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-brand-indigo-500 focus:border-brand-indigo-500 pr-10"
            />
            <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 flex items-center px-3 text-gray-500 hover:text-brand-indigo-600 transition-colors"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                tabIndex={-1}
            >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
        </div>
    );
};

export const QuotationPreviewModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    quotation: Partial<Quotation>;
}> = ({ isOpen, onClose, quotation }) => {
    if (!isOpen) return null;

    const handlePrint = () => {
        window.print();
    };

    // Calculations
    const products = quotation.products || [];
    const services = quotation.services || [];
    const NUM_ROWS = 10; // Fixed number of rows for each table

    const productTotalQty = products.reduce((acc, item) => acc + (Number(item.quantity) || 0), 0);
    const productSubtotal = products.reduce((acc, item) => acc + (item.total || 0), 0);
    const productDiscount = quotation.productDiscount?.amount || 0;
    const productNetTotal = productSubtotal - productDiscount;

    const serviceSubtotal = services.reduce((acc, item) => acc + (item.total || 0), 0);
    const serviceDiscount = quotation.serviceDiscount?.amount || 0;
    const serviceNetTotal = serviceSubtotal - serviceDiscount;
    
    const grandTotal = Math.round(productNetTotal + serviceNetTotal);

    const emptyProductRows = Array.from({ length: Math.max(0, NUM_ROWS - products.length) });
    const emptyServiceRows = Array.from({ length: Math.max(0, NUM_ROWS - services.length) });


    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[100] p-4">
            <style>{`
                @media print {
                    body * {
                        visibility: hidden;
                    }
                    .printable-area, .printable-area * {
                        visibility: visible;
                    }
                    .printable-area {
                        position: absolute;
                        left: 0;
                        top: 0;
                        width: 100%;
                        height: auto;
                        margin: 0;
                        padding: 0;
                        border: none;
                        box-shadow: none;
                        background: white;
                        font-family: serif;
                        color: black;
                    }
                    .no-print {
                        display: none;
                    }
                    .print-table {
                        width: 100%;
                        border-collapse: collapse;
                        font-size: 12px;
                    }
                    .print-table th, .print-table td {
                        border: 1px solid black;
                        padding: 4px 8px;
                        text-align: left;
                    }
                    .print-table th {
                        font-weight: bold;
                    }
                    .text-right { text-align: right !important; }
                    .font-bold { font-weight: bold !important; }
                    .border-none { border: none !important; }
                    .w-auto { width: auto; }
                    .w-full { width: 100%; }
                }
            `}</style>
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl h-[90vh] flex flex-col">
                <div className="printable-area p-6 overflow-y-auto flex-grow" style={{ fontFamily: 'serif' }}>
                   <div className="text-sm">
                        {/* Header */}
                         <div className="flex justify-between items-center text-center border-y-2 border-black py-2 mb-2">
                            <div className="w-1/4">
                                <div className="font-bold text-lg">Quotation No.</div>
                                <div className="font-bold">{quotation.quotationNumber || 'N/A'}</div>
                            </div>
                            <div>
                                <div className="font-bold text-xl">QUOTATION</div>
                                <div className="font-bold text-3xl">II SHUBH HO II</div>
                            </div>
                            <div className="w-1/4"></div>
                        </div>

                        {/* Customer Info */}
                        <table className="print-table border-none w-full mb-2">
                            <tbody>
                                <tr className="border-none">
                                    <td className="border-none w-1/2 align-top">
                                        <div className="flex"><span className="font-bold w-20">Name :</span><span>{quotation.customerName || 'N/A'}</span></div>
                                        <div className="flex"><span className="font-bold w-20">Mobile No:</span><span>{quotation.customerMobile || 'N/A'}</span></div>
                                    </td>
                                    <td className="border-none w-1/2 align-top">
                                        <div className="flex"><span className="font-bold w-28">Trail Date:</span><span>{quotation.trialDate ? new Date(quotation.trialDate).toLocaleDateString() : 'N/A'}</span></div>
                                        <div className="flex"><span className="font-bold w-28">Delivery Date :</span><span>{quotation.deliveryDate ? new Date(quotation.deliveryDate).toLocaleDateString() : 'N/A'}</span></div>
                                        <div className="flex"><span className="font-bold w-28">Salesman :</span><span>{quotation.salesman || 'N/A'}</span></div>
                                        {quotation.status === QuotationStatus.SALE && quotation.saleBillNumber && (
                                            <>
                                                <div className="flex"><span className="font-bold w-28">Sale Bill #:</span><span>{quotation.saleBillNumber}</span></div>
                                                <div className="flex"><span className="font-bold w-28">Sale Bill Date:</span><span>{quotation.saleBillDate ? new Date(quotation.saleBillDate).toLocaleDateString() : 'N/A'}</span></div>
                                            </>
                                        )}
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        {/* Products Table */}
                        <table className="print-table w-full">
                            <thead>
                                <tr>
                                    <th className="w-[5%]">S No</th>
                                    <th className="w-[20%]">Barcode</th>
                                    <th className="w-auto">Description</th>
                                    <th className="w-[10%] text-right">Qty</th>
                                    <th className="w-[15%] text-right">Item Rate</th>
                                    <th className="w-[15%] text-right">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map((item, index) => (
                                    <tr key={`prod-${index}`}>
                                        <td>{index + 1}</td>
                                        <td>{item.barcode}</td>
                                        <td></td>
                                        <td className="text-right">{Number(item.quantity).toFixed(2)}</td>
                                        <td className="text-right">{Number(item.mrp).toFixed(2)}</td>
                                        <td className="text-right">{Number(item.total).toFixed(2)}</td>
                                    </tr>
                                ))}
                                {emptyProductRows.map((_, index) => (<tr key={`prod-empty-${index}`}><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td></tr>))}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colSpan={3} className="font-bold">Total</td>
                                    <td className="font-bold text-right">{productTotalQty.toFixed(2)}</td>
                                    <td className="border-none"></td>
                                    <td className="font-bold text-right">{productSubtotal.toFixed(2)}</td>
                                </tr>
                            </tfoot>
                        </table>
                        
                        <table className="print-table w-full mt-[-1px]"><tbody>
                            <tr>
                                <td className="w-[70%] border-none"></td>
                                <td className="w-[15%] font-bold">Sub Total</td>
                                <td className="w-[15%] font-bold text-right">{productSubtotal.toFixed(2)}</td>
                            </tr>
                            <tr>
                                <td className="border-none"></td>
                                <td className="font-bold">Disc Amt</td>
                                <td className="font-bold text-right">{productDiscount.toFixed(2)}</td>
                            </tr>
                            <tr>
                                <td className="border-none"></td>
                                <td className="font-bold">Product Total</td>
                                <td className="font-bold text-right">{productNetTotal.toFixed(2)}</td>
                            </tr>
                        </tbody></table>

                        {/* Services Table */}
                        <table className="print-table w-full mt-4">
                            <thead>
                                <tr>
                                    <th className="w-[5%]">S No</th>
                                    <th className="w-[20%]">Stitching</th>
                                    <th className="w-auto">Description</th>
                                    <th className="w-[10%] text-right">Qty</th>
                                    <th className="w-[15%] text-right">Item Rate</th>
                                    <th className="w-[15%] text-right">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {services.map((item, index) => (
                                    <tr key={`serv-${index}`}>
                                        <td>{index + 1}</td>
                                        <td>{item.name}</td>
                                        <td></td>
                                        <td className="text-right">{Number(item.quantity).toFixed(2)}</td>
                                        <td className="text-right">{Number(item.mrp).toFixed(2)}</td>
                                        <td className="text-right">{Number(item.total).toFixed(2)}</td>
                                    </tr>
                                ))}
                                {emptyServiceRows.map((_, index) => (<tr key={`serv-empty-${index}`}><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td></tr>))}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colSpan={5} className="font-bold">Total</td>
                                    <td className="font-bold text-right">{serviceSubtotal.toFixed(2)}</td>
                                </tr>
                            </tfoot>
                        </table>

                        <table className="print-table w-full mt-[-1px]"><tbody>
                            <tr>
                                <td className="w-[70%] border-none"></td>
                                <td className="w-[15%] font-bold">Sub Total</td>
                                <td className="w-[15%] font-bold text-right">{serviceSubtotal.toFixed(2)}</td>
                            </tr>
                            <tr>
                                <td className="border-none"></td>
                                <td className="font-bold">Disc Amt</td>
                                <td className="font-bold text-right">{serviceDiscount.toFixed(2)}</td>
                            </tr>
                            <tr>
                                <td className="border-none"></td>
                                <td className="font-bold">Service Total</td>
                                <td className="font-bold text-right">{serviceNetTotal.toFixed(2)}</td>
                            </tr>
                        </tbody></table>

                        {/* Grand Total */}
                        <table className="print-table w-full mt-4"><tfoot>
                            <tr>
                                <td className="w-[70%] font-bold text-xl">GRAND TOTAL</td>
                                <td className="w-[30%] font-bold text-xl text-right">{grandTotal.toFixed(2)}</td>
                            </tr>
                        </tfoot></table>
                   </div>
                </div>
                <div className="no-print p-4 bg-gray-100 border-t flex justify-end items-center space-x-3">
                    <button onClick={handlePrint} className="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-indigo-600 hover:bg-brand-indigo-700">Print</button>
                    <button onClick={onClose} className="px-6 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">Close</button>
                </div>
            </div>
        </div>
    );
};