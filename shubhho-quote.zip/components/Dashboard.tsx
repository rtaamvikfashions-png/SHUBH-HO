import React, { useState, useEffect, useMemo, useContext } from 'react';
import { AuthContext } from '../auth/AuthContext';
import * as storage from '../services/storageService';
import { QUOTATIONS_KEY, USERS_KEY } from '../constants';
import { Quotation, QuotationStatus, User, CancellationReason } from '../types';

// --- Date Helper Functions ---
const getToday = () => {
    const date = new Date();
    return date.toISOString().split('T')[0];
};

const getWeekRange = () => {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - end.getDay()); // Start of week (Sunday)
    return {
        start: start.toISOString().split('T')[0],
        end: end.toISOString().split('T')[0],
    };
};

const getMonthRange = () => {
    const date = new Date();
    const start = new Date(date.getFullYear(), date.getMonth(), 1);
    return {
        start: start.toISOString().split('T')[0],
        end: date.toISOString().split('T')[0],
    };
};

// --- Doughnut Chart Components ---
const DoughnutChart: React.FC<{ data: any[], total: number }> = ({ data, total }) => {
    const [tooltip, setTooltip] = useState({ visible: false, content: '', x: 0, y: 0 });

    if (total === 0) return null;

    let cumulativeAngle = -Math.PI / 2;

    const handleMouseMove = (event: React.MouseEvent, sliceData: any) => {
        const percentage = total > 0 ? ((sliceData.value / total) * 100).toFixed(1) : 0;
        setTooltip({
            visible: true,
            content: `${sliceData.name}: ${sliceData.value} (${percentage}%)`,
            x: event.clientX,
            y: event.clientY,
        });
    };
    
    const handleMouseLeave = () => {
        setTooltip(p => ({ ...p, visible: false }));
    };
    
    const radius = 80;

    return (
        <div className="relative">
            <svg viewBox="-100 -100 200 200" width="220" height="220">
                {data.map(slice => {
                    const startAngle = cumulativeAngle;
                    const sliceAngle = (slice.value / total) * 2 * Math.PI;
                    const endAngle = startAngle + sliceAngle;
                    cumulativeAngle = endAngle;

                    const getCoord = (angle: number) => [radius * Math.cos(angle), radius * Math.sin(angle)];
                    const [startX, startY] = getCoord(startAngle);
                    const [endX, endY] = getCoord(endAngle);
                    const largeArcFlag = endAngle - startAngle > Math.PI ? 1 : 0;
                    const pathData = `M 0 0 L ${startX} ${startY} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX} ${endY} Z`;

                    return (
                        <path
                            key={slice.name}
                            d={pathData}
                            fill={slice.color}
                            onMouseMove={e => handleMouseMove(e, slice)}
                            onMouseLeave={handleMouseLeave}
                            className="cursor-pointer transition-transform transform hover:scale-105"
                        />
                    );
                })}
                <circle cx="0" cy="0" r="45" fill="white" />
                <g className="pointer-events-none">
                    <text textAnchor="middle" y="-5" className="font-bold text-4xl fill-brand-indigo-800">{total}</text>
                    <text textAnchor="middle" y="15" className="text-sm fill-gray-500">Quotations</text>
                </g>
            </svg>
            {tooltip.visible && (
                <div
                    className="fixed bg-gray-800 text-white text-lg font-bold p-3 rounded-lg shadow-xl z-50 pointer-events-none"
                    style={{ top: tooltip.y, left: tooltip.x, transform: 'translate(15px, -100%)' }}
                >
                    {tooltip.content}
                </div>
            )}
        </div>
    );
};


const Legend: React.FC<{ data: any[] }> = ({ data }) => (
    <ul className="space-y-2">
        {data.map(item => (
            <li key={item.name} className="flex items-center text-sm">
                <span className="w-4 h-4 rounded-full mr-3" style={{ backgroundColor: item.color }}></span>
                <span className="font-semibold text-gray-700">{item.name}</span>
            </li>
        ))}
    </ul>
);


// --- Sub-components for Dashboard ---
const HorizontalBarChart: React.FC<{ data: { name: string; count: number }[]; title: string }> = ({ data, title }) => {
    if (!data || data.length === 0) {
        return (
            <div className="p-4 bg-white rounded-lg shadow-md h-full flex flex-col">
                <h3 className="font-bold text-gray-700 mb-4">{title}</h3>
                <div className="flex-grow flex items-center justify-center">
                    <p className="text-sm text-gray-500">No finalized services for this period.</p>
                </div>
            </div>
        );
    }
    
    const maxCount = Math.max(...data.map(item => item.count), 1);

    return (
        <div className="p-4 bg-white rounded-lg shadow-md h-full flex flex-col">
            <h3 className="font-bold text-gray-700 mb-4">{title}</h3>
            <div className="space-y-4 flex-grow flex flex-col justify-center">
                {data.map(item => (
                    <div key={item.name}>
                        <div className="flex justify-between items-center text-sm font-medium text-gray-700 mb-1">
                            <span>{item.name}</span>
                            <span className="font-bold text-brand-indigo-700">{item.count}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-brand-indigo-600 h-2 rounded-full transition-all duration-500" style={{ width: `${(item.count / maxCount) * 100}%` }}></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const ReasonChart: React.FC<{ data: { name: string; count: number }[]; title: string }> = ({ data, title }) => (
    <div className="p-4 bg-white rounded-lg shadow-md">
        <h3 className="font-bold text-gray-700 mb-2">{title}</h3>
        <div className="space-y-2">
            {data.length === 0 ? <p className="text-sm text-gray-500">No data for this period.</p> : data.map(item => (
                <div key={item.name}>
                    <div className="flex justify-between text-sm mb-1">
                        <span>{item.name}</span>
                        <span className="font-semibold">{item.count}</span>
                    </div>
                </div>
            ))}
        </div>
    </div>
);


export const Dashboard: React.FC = () => {
    const { currentUser } = useContext(AuthContext);

    // Raw Data State
    const [allQuotations, setAllQuotations] = useState<Quotation[]>([]);
    const [users, setUsers] = useState<User[]>([]);

    // Filter State
    const [startDate, setStartDate] = useState(getMonthRange().start);
    const [endDate, setEndDate] = useState(getToday());
    const [selectedUserId, setSelectedUserId] = useState('all'); // Admin filter

    useEffect(() => {
        // Load all data once on component mount
        setAllQuotations(storage.getCollection<Quotation>(QUOTATIONS_KEY));
        if (currentUser?.isAdmin) {
            setUsers(storage.getCollection<User>(USERS_KEY));
        }
    }, [currentUser]);

    const filteredQuotations = useMemo(() => {
        return allQuotations.filter(q => {
            const quotationDate = new Date(q.createdAt).getTime();
            const startDateTime = startDate ? new Date(startDate).getTime() : 0;
            const endDateTime = endDate ? new Date(endDate).setHours(23, 59, 59, 999) : Date.now();
            
            const isDateInRange = quotationDate >= startDateTime && quotationDate <= endDateTime;
            if (!isDateInRange) return false;

            if (currentUser?.isAdmin) {
                return selectedUserId === 'all' || q.userId === selectedUserId;
            } else {
                return q.userId === currentUser?.mobile;
            }
        });
    }, [allQuotations, startDate, endDate, selectedUserId, currentUser]);
    
    // --- Memoized calculations for analytics ---
    const { doughnutChartData, totalQuotations } = useMemo(() => {
        const sale = filteredQuotations.filter(q => q.status === QuotationStatus.SALE).length;
        const draft = filteredQuotations.filter(q => q.status === QuotationStatus.DRAFT).length;
        const cancelAndWalkout = filteredQuotations.filter(
            q => q.status === QuotationStatus.CANCEL || q.status === QuotationStatus.WALK_OUT
        ).length;
        
        const total = filteredQuotations.length;
    
        const data = [
            { name: 'Sale', value: sale, color: '#22c55e' },
            { name: 'Draft', value: draft, color: '#3b82f6' },
            { name: 'Cancel & WalkOut', value: cancelAndWalkout, color: '#ef4444' },
        ].filter(item => item.value > 0);
    
        return { doughnutChartData: data, totalQuotations: total };
    }, [filteredQuotations]);

    const cancellationReasons = useMemo(() => {
        const reasons = new Map<string, number>();
        filteredQuotations
            .filter(q => (q.status === QuotationStatus.CANCEL || q.status === QuotationStatus.WALK_OUT) && q.cancellationReason)
            .forEach(q => {
                const category = (q.cancellationReason as CancellationReason).category;
                reasons.set(category, (reasons.get(category) || 0) + 1);
            });
        return Array.from(reasons.entries()).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
    }, [filteredQuotations]);

    const topStitchingServices = useMemo(() => {
        const services = new Map<string, number>();
        filteredQuotations
            .filter(q => q.status === QuotationStatus.SALE)
            .forEach(q => {
                q.services.forEach(s => {
                    services.set(s.name, (services.get(s.name) || 0) + s.quantity);
                });
            });
        return Array.from(services.entries())
            .map(([name, count]) => ({ name, count }))
            .sort((a,b) => b.count - a.count)
            .slice(0, 5);
    }, [filteredQuotations]);

    const financialSummary = useMemo(() => {
        return filteredQuotations
            .filter(q => q.status === QuotationStatus.SALE || q.status === QuotationStatus.CANCEL)
            .sort((a,b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    }, [filteredQuotations]);
    
    const financialSubtotal = financialSummary.reduce((acc, q) => acc + q.grandTotal, 0);

    const setDatePreset = (preset: 'today' | 'week' | 'month') => {
        if (preset === 'today') {
            const today = getToday();
            setStartDate(today);
            setEndDate(today);
        } else if (preset === 'week') {
            const { start, end } = getWeekRange();
            setStartDate(start);
            setEndDate(end);
        } else if (preset === 'month') {
            const { start, end } = getMonthRange();
            setStartDate(start);
            setEndDate(end);
        }
    };

    return (
        <div className="space-y-6">
            {/* Filter Bar */}
            <div className="p-4 bg-white rounded-lg shadow-md flex flex-col sm:flex-row flex-wrap gap-4 items-stretch sm:items-center">
                <div className="flex-grow flex flex-col sm:flex-row flex-wrap items-center gap-4">
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                        <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="p-2 border rounded-md text-sm w-full" />
                        <span className="text-gray-500">to</span>
                        <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="p-2 border rounded-md text-sm w-full" />
                    </div>
                    <div className="flex items-center gap-2">
                        <button onClick={() => setDatePreset('today')} className="px-3 py-1.5 text-sm bg-gray-200 rounded-md hover:bg-gray-300">Today</button>
                        <button onClick={() => setDatePreset('week')} className="px-3 py-1.5 text-sm bg-gray-200 rounded-md hover:bg-gray-300">Week</button>
                        <button onClick={() => setDatePreset('month')} className="px-3 py-1.5 text-sm bg-gray-200 rounded-md hover:bg-gray-300">Month</button>
                    </div>
                </div>
                {currentUser?.isAdmin && (
                     <select value={selectedUserId} onChange={e => setSelectedUserId(e.target.value)} className="p-2 border rounded-md text-sm w-full sm:w-auto">
                        <option value="all">All Users</option>
                        {users.map(user => <option key={user.id} value={user.mobile}>{user.name}</option>)}
                    </select>
                )}
            </div>

             {/* Main Analytics Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="p-4 bg-white rounded-lg shadow-md">
                    <h3 className="font-bold text-gray-700 mb-2">Quotation Overview</h3>
                    {totalQuotations > 0 ? (
                        <div className="flex flex-col md:flex-row items-center justify-center gap-6">
                            <DoughnutChart data={doughnutChartData} total={totalQuotations} />
                            <div className="flex-shrink-0">
                                <Legend data={doughnutChartData} />
                            </div>
                        </div>
                    ) : (
                        <div className="flex items-center justify-center h-full min-h-[250px] text-gray-500">
                             <p>No data available for the selected period.</p>
                        </div>
                    )}
                </div>
                <HorizontalBarChart data={topStitchingServices} title="Top 5 Stitching Services (from Sales)" />
            </div>

            <ReasonChart data={cancellationReasons} title="Cancellation & Walk-out Reasons" />

            {/* Financial Summary */}
             <div className="p-4 bg-white rounded-lg shadow-md">
                <h3 className="font-bold text-gray-700 mb-3">Financial Summary (Sale & Cancel)</h3>
                 <div className="overflow-x-auto">
                    <table className="min-w-full text-sm">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                                <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase">Amount</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {financialSummary.map(q => (
                                <tr key={q.id}>
                                    <td className="px-3 py-2 text-gray-500">{new Date(q.updatedAt).toLocaleDateString()}</td>
                                    <td className="px-3 py-2 font-medium">{q.customerName}</td>
                                    <td className="px-3 py-2">
                                        <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                                            q.status === QuotationStatus.SALE ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                        }`}>{q.status}</span>
                                    </td>
                                    <td className="px-3 py-2 text-right font-semibold">₹{q.grandTotal.toFixed(2)}</td>
                                </tr>
                            ))}
                        </tbody>
                        <tfoot className="bg-gray-100">
                            <tr>
                                <td colSpan={3} className="px-3 py-2 text-right font-bold text-gray-700">Subtotal of Listed</td>
                                <td className="px-3 py-2 text-right font-bold text-lg text-gray-800">₹{financialSubtotal.toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                 </div>
            </div>
        </div>
    );
};