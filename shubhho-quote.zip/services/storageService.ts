
function generateId(): string {
    return `${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 9)}`;
}

export function getCollection<T>(key: string): T[] {
    try {
        const item = window.localStorage.getItem(key);
        return item ? JSON.parse(item) : [];
    } catch (error) {
        console.error(`Error reading collection "${key}" from localStorage`, error);
        return [];
    }
}

export function getDocument<T extends { id: string }>(key: string, id: string): T | null {
    const collection = getCollection<T>(key);
    return collection.find(doc => doc.id === id) || null;
}

export function addDocument<T extends { id: string }>(key: string, data: Omit<T, 'id'>): T {
    const collection = getCollection<T>(key);
    const newDocument = { ...data, id: generateId() } as T;
    const newCollection = [...collection, newDocument];
    try {
        window.localStorage.setItem(key, JSON.stringify(newCollection));
        return newDocument;
    } catch (error) {
        console.error(`Error adding document to "${key}" in localStorage`, error);
        throw error;
    }
}

export function updateDocument<T extends { id: string }>(key: string, id: string, data: Partial<Omit<T, 'id'>>): T {
    const collection = getCollection<T>(key);
    let updatedDocument: T | null = null;
    const newCollection = collection.map(doc => {
        if (doc.id === id) {
            updatedDocument = { ...doc, ...data };
            return updatedDocument;
        }
        return doc;
    });

    if (!updatedDocument) {
        throw new Error(`Document with id "${id}" not found in collection "${key}"`);
    }

    try {
        window.localStorage.setItem(key, JSON.stringify(newCollection));
        return updatedDocument;
    } catch (error) {
        console.error(`Error updating document in "${key}" in localStorage`, error);
        throw error;
    }
}

export function deleteDocuments(key: string, ids: string[]): void {
    const collection = getCollection<{ id: string }>(key);
    const newCollection = collection.filter(doc => !ids.includes(doc.id));
    try {
        window.localStorage.setItem(key, JSON.stringify(newCollection));
    } catch (error) {
        console.error(`Error deleting documents from "${key}" in localStorage`, error);
        throw error;
    }
}
