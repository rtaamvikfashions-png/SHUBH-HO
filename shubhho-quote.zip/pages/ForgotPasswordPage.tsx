
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import * as storage from '../services/storageService';
import { USERS_KEY } from '../constants';
import { User } from '../types';
import { hashPassword } from '../auth/hash';
import { PasswordInput } from '../components/SharedComponents';

type Step = 'enterMobile' | 'answerQuestion' | 'resetPassword' | 'success';

const ForgotPasswordPage: React.FC = () => {
    const [step, setStep] = useState<Step>('enterMobile');
    const [mobile, setMobile] = useState('');
    const [user, setUser] = useState<User | null>(null);
    const [secretAnswer, setSecretAnswer] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const handleMobileSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!/^\d{10}$/.test(mobile)) {
            setError('Mobile number must be 10 digits.');
            return;
        }
        const users = storage.getCollection<User>(USERS_KEY);
        const foundUser = users.find(u => u.mobile === mobile);
        if (foundUser) {
            setUser(foundUser);
            setStep('answerQuestion');
        } else {
            setError('No account found with this mobile number.');
        }
    };

    const handleAnswerSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!user || !secretAnswer.trim()) {
            setError('Secret answer is required.');
            return;
        }
        setLoading(true);
        const answerHash = await hashPassword(secretAnswer.toLowerCase().trim());
        setLoading(false);
        if (answerHash === user.secretAnswerHash) {
            setStep('resetPassword');
        } else {
            setError('Secret answer is incorrect.');
        }
    };

    const handlePasswordResetSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (newPassword.length < 6) {
            setError('Password must be at least 6 characters long.');
            return;
        }
        if (newPassword !== confirmPassword) {
            setError('Passwords do not match.');
            return;
        }
        if (!user) {
            setError('An unexpected error occurred. Please start over.');
            return;
        }
        setLoading(true);
        const newPasswordHash = await hashPassword(newPassword);
        storage.updateDocument<User>(USERS_KEY, user.id, { passwordHash: newPasswordHash });
        setLoading(false);
        setStep('success');
    };

    const renderStep = () => {
        switch (step) {
            case 'enterMobile':
                return (
                    <form className="space-y-6" onSubmit={handleMobileSubmit}>
                        <p className="text-sm text-gray-600">Enter your mobile number to begin the password recovery process.</p>
                        <div>
                            <label htmlFor="mobile" className="text-sm font-medium text-gray-700">Mobile Number</label>
                            <input id="mobile" type="tel" value={mobile} onChange={e => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-indigo-500 focus:border-brand-indigo-500" />
                        </div>
                        <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-indigo-700 hover:bg-brand-indigo-800">Next</button>
                    </form>
                );
            case 'answerQuestion':
                return (
                    <form className="space-y-6" onSubmit={handleAnswerSubmit}>
                        <div className="text-sm text-gray-800">
                            <p className="font-medium">Secret Question:</p>
                            <p className="mt-1 p-3 bg-gray-100 rounded-md">{user?.secretQuestion}</p>
                        </div>
                        <div>
                            <label htmlFor="secret-answer" className="text-sm font-medium text-gray-700">Your Answer</label>
                            <input id="secret-answer" type="text" value={secretAnswer} onChange={e => setSecretAnswer(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-indigo-500 focus:border-brand-indigo-500" />
                        </div>
                        <button type="submit" disabled={loading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-indigo-700 hover:bg-brand-indigo-800 disabled:bg-brand-indigo-400">
                            {loading ? 'Verifying...' : 'Verify Answer'}
                        </button>
                    </form>
                );
            case 'resetPassword':
                return (
                    <form className="space-y-6" onSubmit={handlePasswordResetSubmit}>
                        <p className="text-sm text-gray-600">Verification successful. Please enter your new password.</p>
                        <div>
                            <label className="text-sm font-medium text-gray-700">New Password</label>
                            <PasswordInput value={newPassword} onChange={e => setNewPassword(e.target.value)} required className="mt-1" placeholder="At least 6 characters" />
                        </div>
                        <div>
                            <label className="text-sm font-medium text-gray-700">Confirm New Password</label>
                            <PasswordInput value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="mt-1" />
                        </div>
                        <button type="submit" disabled={loading} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-indigo-700 hover:bg-brand-indigo-800 disabled:bg-brand-indigo-400">
                            {loading ? 'Resetting...' : 'Reset Password'}
                        </button>
                    </form>
                );
            case 'success':
                return (
                    <div className="space-y-6 text-center">
                        <p className="text-green-600 font-semibold">Your password has been reset successfully!</p>
                        <button onClick={() => navigate('/login')} className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-indigo-700 hover:bg-brand-indigo-800">
                            Back to Login
                        </button>
                    </div>
                );
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-brand-indigo-50 p-4">
            <div className="w-full max-w-md p-6 sm:p-8 space-y-6 sm:space-y-8 bg-white rounded-2xl shadow-lg">
                <div className="text-center">
                    <h2 className="mt-2 text-2xl font-bold text-brand-indigo-800">
                        Password Recovery
                    </h2>
                </div>
                {error && <p className="text-sm text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}
                {renderStep()}
                {step !== 'success' && (
                    <p className="text-sm text-center text-gray-600 mt-4">
                        Remember your password?{' '}
                        <Link to="/login" className="font-medium text-brand-indigo-600 hover:text-brand-indigo-500">
                            Back to Login
                        </Link>
                    </p>
                )}
            </div>
        </div>
    );
};

export default ForgotPasswordPage;
