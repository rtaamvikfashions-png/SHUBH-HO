
import React, { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../auth/AuthContext';
import { PasswordInput } from '../components/SharedComponents';

const LoginPage: React.FC = () => {
    const [mobile, setMobile] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const { login } = useContext(AuthContext);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        
        if (!mobile || !password) {
            setError('Mobile number and password are required.');
            return;
        }
        setLoading(true);
        const success = await login(mobile, password);
        setLoading(false);
        if (success) {
            navigate('/');
        } else {
            setError('Invalid mobile number or password.');
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-brand-indigo-50 p-4">
            <div className="w-full max-w-md p-6 sm:p-8 space-y-6 sm:space-y-8 bg-white rounded-2xl shadow-lg">
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-brand-yellow-500 tracking-wider">II SHUBH HO II</h1>
                    <h2 className="mt-2 text-2xl font-bold text-brand-indigo-800">
                        Sign in to your account
                    </h2>
                </div>
                <form className="space-y-6" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="mobile" className="text-sm font-medium text-gray-700">
                            Mobile Number / Username
                        </label>
                        <input
                            id="mobile"
                            name="mobile"
                            type="text"
                            autoComplete="username"
                            required
                            value={mobile}
                            onChange={(e) => setMobile(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-brand-indigo-500 focus:border-brand-indigo-500"
                            placeholder="e.g., admin or 1234567890"
                        />
                    </div>
                    <div>
                        <div className="flex items-center justify-between">
                            <label htmlFor="password"className="text-sm font-medium text-gray-700">
                                Password
                            </label>
                            <div className="text-sm">
                                <Link to="/forgot-password" className="font-medium text-brand-indigo-600 hover:text-brand-indigo-500">
                                    Forgot password?
                                </Link>
                            </div>
                        </div>
                        <PasswordInput
                            id="password"
                            name="password"
                            autoComplete="current-password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="mt-1"
                        />
                    </div>
                    
                    {error && <p className="text-sm text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}

                    <div>
                        <button
                            type="submit"
                            disabled={loading}
                            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-brand-indigo-700 hover:bg-brand-indigo-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-indigo-500 disabled:bg-brand-indigo-400 transition-colors"
                        >
                            {loading ? 'Signing in...' : 'Sign In'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default LoginPage;
