
import React, { useState, useEffect, useMemo, useContext, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Printer } from 'lucide-react';
import { Quotation, QuotationStatus, User } from '../types';
import * as storage from '../services/storageService';
import { QUOTATIONS_KEY, USERS_KEY } from '../constants';
import { ConfirmationDialog, StatusIndicator, QuotationPreviewModal } from '../components/SharedComponents';
import { AuthContext } from '../auth/AuthContext';

type Tab = 'ALL' | 'SALE' | 'DRAFT' | 'CANCELED_WALKOUT';
type SortKey = 'quotationNumber' | 'customerName' | 'updatedAt' | 'grandTotal';

const TabButton: React.FC<{ activeTab: Tab, tab: Tab, label: string, onClick: (tab: Tab) => void }> = 
    ({ activeTab, tab, label, onClick }) => (
    <button onClick={() => onClick(tab)} className={`whitespace-nowrap py-3 px-4 text-sm font-medium transition-colors duration-200 ${activeTab === tab 
        ? 'border-b-2 border-brand-indigo-600 text-brand-indigo-600' 
        : 'border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
        {label}
    </button>
);

const HistoryPage: React.FC = () => {
    const navigate = useNavigate();
    const { currentUser } = useContext(AuthContext);

    const [quotations, setQuotations] = useState<Quotation[]>([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<Tab>('ALL');
    const [selected, setSelected] = useState<string[]>([]);
    const [isDeleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [previewQuotation, setPreviewQuotation] = useState<Quotation | null>(null);
    const [userMap, setUserMap] = useState<Map<string, string>>(new Map());

    const [searchTerm, setSearchTerm] = useState('');
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; direction: 'asc' | 'desc' }>({ key: 'quotationNumber', direction: 'asc' });
    
    const headerCheckboxRef = useRef<HTMLInputElement>(null);

    const loadData = () => {
        if (!currentUser) return;
        setLoading(true);
        const allQuotations = storage.getCollection<Quotation>(QUOTATIONS_KEY);
        setQuotations(allQuotations);

        if (currentUser.isAdmin) {
            const users = storage.getCollection<User>(USERS_KEY);
            const map = new Map<string, string>();
            users.forEach(user => {
                map.set(user.mobile, user.name);
            });
            setUserMap(map);
        }

        setLoading(false);
    };

    useEffect(() => {
        loadData();
    }, [currentUser]);

    const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const [key, direction] = e.target.value.split('_');
        setSortConfig({ key: key as SortKey, direction: direction as 'asc' | 'desc' });
    };

    const filteredQuotations = useMemo(() => {
        if (!currentUser) return [];

        let userQuotations = quotations;
        if (!currentUser.isAdmin) {
            userQuotations = quotations.filter(q => q.userId === currentUser.mobile);
        }

        let tabFiltered = userQuotations;
        if (activeTab !== 'ALL') {
             tabFiltered = userQuotations.filter(q => {
                if (activeTab === 'CANCELED_WALKOUT') {
                    return q.status === QuotationStatus.CANCEL || q.status === QuotationStatus.WALK_OUT;
                }
                return q.status === activeTab;
            });
        }
        
        const searchFiltered = tabFiltered.filter(q => {
            const term = searchTerm.toLowerCase();
            return q.customerName.toLowerCase().includes(term) || q.customerMobile.includes(term);
        });
        
        const sorted = [...searchFiltered];
        sorted.sort((a, b) => {
            const { key, direction } = sortConfig;
            let comparison = 0;
            switch(key) {
                case 'quotationNumber':
                    const numA = parseInt(a.quotationNumber?.split('/')[1] || '0', 10);
                    const numB = parseInt(b.quotationNumber?.split('/')[1] || '0', 10);
                    comparison = numA - numB;
                    break;
                case 'customerName':
                    comparison = a.customerName.localeCompare(b.customerName);
                    break;
                case 'grandTotal':
                    comparison = a.grandTotal - b.grandTotal;
                    break;
                case 'updatedAt':
                    const dateA = new Date(a.updatedAt).getTime();
                    const dateB = new Date(b.updatedAt).getTime();
                    comparison = dateB - dateA; // Default to newest first
                    break;
                default:
                    comparison = 0;
            }
            return direction === 'asc' ? comparison : -comparison;
        });
        return sorted;
    }, [quotations, activeTab, currentUser, searchTerm, sortConfig]);
    
    useEffect(() => {
        if (headerCheckboxRef.current) {
            const numSelected = selected.length;
            const numFiltered = filteredQuotations.length;
            headerCheckboxRef.current.checked = numSelected === numFiltered && numFiltered > 0;
            headerCheckboxRef.current.indeterminate = numSelected > 0 && numSelected < numFiltered;
        }
    }, [selected, filteredQuotations]);

    const handleSelect = (id: string) => {
        setSelected(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            setSelected(filteredQuotations.map(q => q.id));
        } else {
            setSelected([]);
        }
    };

    const handleDeleteSelected = () => {
        storage.deleteDocuments(QUOTATIONS_KEY, selected);
        setQuotations(prev => prev.filter(q => !selected.includes(q.id)));
        setSelected([]);
        setDeleteConfirmOpen(false);
    };
    
    const handleRowClick = (id: string) => {
        if (id) {
           navigate(`/quotation/${id}`);
        }
    };

    if (!currentUser) return null;

    return (
        <>
            <QuotationPreviewModal isOpen={!!previewQuotation} onClose={() => setPreviewQuotation(null)} quotation={previewQuotation || {}} />
            <ConfirmationDialog
                isOpen={isDeleteConfirmOpen}
                onClose={() => setDeleteConfirmOpen(false)}
                onConfirm={handleDeleteSelected}
                title="Confirm Deletion"
                message={`Are you sure you want to delete ${selected.length} item(s)? This action cannot be undone.`}
            />
            <div className="max-w-7xl mx-auto bg-white p-2 sm:p-6 rounded-xl shadow-lg mt-8">
                <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
                    <h2 className="text-xl font-bold text-gray-800">Customer History</h2>
                    {selected.length > 0 && (
                        <button onClick={() => setDeleteConfirmOpen(true)} className="px-4 py-2 text-sm text-white bg-red-600 rounded-md hover:bg-red-700 transition">
                            Delete Selected ({selected.length})
                        </button>
                    )}
                </div>
                
                <div className="border-b border-gray-200">
                    <nav className="-mb-px flex space-x-2 sm:space-x-6 overflow-x-auto">
                        <TabButton activeTab={activeTab} tab="ALL" label="All" onClick={setActiveTab} />
                        <TabButton activeTab={activeTab} tab="SALE" label="Sale" onClick={setActiveTab} />
                        <TabButton activeTab={activeTab} tab="DRAFT" label="Drafts" onClick={setActiveTab} />
                        <TabButton activeTab={activeTab} tab="CANCELED_WALKOUT" label="Cancel / Walk-outs" onClick={setActiveTab} />
                    </nav>
                </div>

                <div className="p-4 bg-gray-50 border-b border-gray-200 flex flex-col sm:flex-row gap-4 items-center">
                    <div className="relative flex-grow w-full">
                        <input
                            type="text"
                            placeholder="Filter by Customer Name or Mobile..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="p-2 w-full border rounded-md shadow-sm text-sm"
                        />
                    </div>
                    <div className="relative w-full sm:w-auto">
                        <select
                            value={`${sortConfig.key}_${sortConfig.direction}`}
                            onChange={handleSortChange}
                            className="p-2 w-full border rounded-md shadow-sm appearance-none pr-8 text-sm"
                        >
                            <option value="updatedAt_desc">Sort by Date (Newest)</option>
                            <option value="updatedAt_asc">Sort by Date (Oldest)</option>
                            <option value="quotationNumber_asc">Sort by Bill # (Asc)</option>
                            <option value="quotationNumber_desc">Sort by Bill # (Desc)</option>
                            <option value="customerName_asc">Sort by Customer (A-Z)</option>
                            <option value="customerName_desc">Sort by Customer (Z-A)</option>
                            <option value="grandTotal_desc">Sort by Net Total (High-Low)</option>
                            <option value="grandTotal_asc">Sort by Net Total (Low-High)</option>
                        </select>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    {loading ? <p className="text-center p-8 text-gray-500">Loading History...</p> : (
                        <table className="min-w-full divide-y divide-gray-200 text-sm">
                            <thead className="bg-gray-50">
                                <tr>
                                    <th className="p-2 sm:p-3 w-12 text-left">
                                        <input 
                                            type="checkbox" 
                                            ref={headerCheckboxRef}
                                            onChange={handleSelectAll} 
                                            className="rounded border-gray-300 text-brand-indigo-600 focus:ring-brand-indigo-500"
                                        />
                                    </th>
                                    <th className="px-2 sm:px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quotation #</th>
                                    <th className="px-2 sm:px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                                    {currentUser.isAdmin && <th className="hidden lg:table-cell px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>}
                                    <th className="hidden md:table-cell px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Updated</th>
                                    <th className="px-2 sm:px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th className="px-2 sm:px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sale Info</th>
                                    <th className="px-2 sm:px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Gross Total</th>
                                    <th className="px-2 sm:px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Discount</th>
                                    <th className="px-2 sm:px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Net Total</th>
                                    <th className="px-2 sm:px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {filteredQuotations.length === 0 ? (
                                    <tr><td colSpan={currentUser.isAdmin ? 11 : 10} className="text-center p-8 text-gray-500">No quotations found for the current filter.</td></tr>
                                ) : filteredQuotations.map(q => {
                                    const grossTotal = q.productSubtotal + q.serviceSubtotal;
                                    const discount = (q.productDiscount?.amount || 0) + (q.serviceDiscount?.amount || 0);

                                    return (
                                    <tr key={q.id} className={`${selected.includes(q.id) ? 'bg-brand-indigo-50' : ''} hover:bg-gray-50 transition-colors duration-150`}>
                                        <td className="p-2 sm:p-3 w-12"><input type="checkbox" checked={selected.includes(q.id)} onChange={() => handleSelect(q.id)} className="rounded border-gray-300 text-brand-indigo-600 focus:ring-brand-indigo-500"/></td>
                                        <td className="px-2 sm:px-4 py-3 font-mono text-gray-600 cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            {q.quotationNumber}
                                        </td>
                                        <td className="px-2 sm:px-4 py-3 cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            <div className="font-medium text-gray-900">{q.customerName}</div>
                                            <div className="text-gray-500">{q.customerMobile}</div>
                                        </td>
                                        {currentUser.isAdmin && <td className="hidden lg:table-cell px-4 py-3 text-gray-600">{userMap.get(q.userId) || q.userId}</td>}
                                        <td className="hidden md:table-cell px-4 py-3 text-gray-500 cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            {q.updatedAt ? new Date(q.updatedAt).toLocaleString() : 'N/A'}
                                        </td>
                                        <td className="px-2 sm:px-4 py-3 cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            <StatusIndicator status={q.status} />
                                        </td>
                                        <td className="px-2 sm:px-4 py-3 cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            {q.status === QuotationStatus.SALE && q.saleBillNumber && (
                                                <div>
                                                    <div className="font-medium text-gray-800">{q.saleBillNumber}</div>
                                                    {q.saleBillDate && <div className="text-gray-500">{new Date(q.saleBillDate).toLocaleDateString()}</div>}
                                                </div>
                                            )}
                                        </td>
                                        <td className="px-2 sm:px-4 py-3 font-semibold text-gray-700 text-right cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            ₹{grossTotal.toFixed(2)}
                                        </td>
                                        <td className="px-2 sm:px-4 py-3 font-semibold text-red-600 text-right cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            -₹{discount.toFixed(2)}
                                        </td>
                                        <td className="px-2 sm:px-4 py-3 font-bold text-gray-900 text-right cursor-pointer" onClick={() => handleRowClick(q.id)}>
                                            ₹{q.grandTotal.toFixed(2)}
                                        </td>
                                        <td className="px-2 sm:px-4 py-3 text-center">
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    setPreviewQuotation(q);
                                                }}
                                                className="p-2 text-gray-500 hover:text-brand-indigo-600 rounded-full hover:bg-gray-100 transition-colors"
                                                title="Preview & Print"
                                            >
                                                <Printer size={18} />
                                            </button>
                                        </td>
                                    </tr>
                                )})}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        </>
    );
};

export default HistoryPage;