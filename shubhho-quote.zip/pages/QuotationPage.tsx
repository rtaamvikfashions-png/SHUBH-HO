
import React, { useState, useEffect, useCallback, useContext } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { PlusCircle, Trash2, X, Plus, Save } from 'lucide-react';
import { Quotation, Salesman, ServiceItem, QuotationStatus, QuotationItem, StitchingItem, CancellationReason } from '../types';
import * as storage from '../services/storageService';
import { QUOTATIONS_KEY, SALESMEN_KEY, SERVICE_ITEMS_KEY } from '../constants';
import { FeedbackPopup, CancelModal } from '../components/SharedComponents';
import { AuthContext } from '../auth/AuthContext';

const DateInput: React.FC<{ label: string; value: string; onChange: (value: string) => void; }> = ({ label, value, onChange }) => (
    <div className="flex items-center justify-end">
        <label className="text-sm font-semibold text-gray-700 mr-2 whitespace-nowrap">{label}</label>
        <input type="date" value={value} onChange={e => onChange(e.target.value)} className="block border-gray-300 rounded-md shadow-sm text-sm p-1.5 w-36 focus:ring-brand-indigo-500 focus:border-brand-indigo-500" />
    </div>
);

const getUserInitials = (name: string): string => {
    if (!name) return 'NA';
    const parts = name.trim().split(/\s+/);
    if (parts.length > 1) {
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    if (parts[0].length >= 2) {
        return parts[0].substring(0, 2).toUpperCase();
    }
    return parts[0].toUpperCase();
};

const generateNextQuotationNumber = (userId: string, userName:string, allQuotations: Quotation[]): string => {
    const userQuotations = allQuotations.filter(q => q.userId === userId && q.quotationNumber);
    let maxNum = 0;
    userQuotations.forEach(q => {
        const parts = q.quotationNumber.split('/');
        if (parts.length === 2) {
            const num = parseInt(parts[1], 10);
            if (!isNaN(num) && num > maxNum) {
                maxNum = num;
            }
        }
    });
    const nextNum = maxNum + 1;
    const paddedNum = String(nextNum).padStart(3, '0');
    const initials = getUserInitials(userName);
    return `${initials}/${paddedNum}`;
}

const ConfirmSaleModal: React.FC<{
    onClose: () => void;
    onSubmit: (details: { billNumber: string; billDate: string }) => void;
}> = ({ onClose, onSubmit }) => {
    const [billNumber, setBillNumber] = useState('');
    const [billDate, setBillDate] = useState(new Date().toISOString().split('T')[0]);
    const [error, setError] = useState('');

    const handleSubmit = () => {
        if (!billNumber.trim()) {
            setError('Sale Bill Number is required.');
            return;
        }
        if (!billDate) {
            setError('Sale Bill Date is required.');
            return;
        }
        onSubmit({ billNumber, billDate });
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md relative">
                <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-gray-600"><X size={24} /></button>
                <h3 className="text-lg font-bold text-gray-800">Confirm Sale Details</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label className="text-sm font-medium text-gray-700">Actual Sale Bill Number</label>
                        <input
                            type="text"
                            value={billNumber}
                            onChange={(e) => setBillNumber(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-brand-indigo-500"
                            placeholder="Enter final bill number"
                        />
                    </div>
                    <div>
                        <label className="text-sm font-medium text-gray-700">Date of Sale Bill</label>
                        <input
                            type="date"
                            value={billDate}
                            onChange={(e) => setBillDate(e.target.value)}
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-brand-indigo-500"
                        />
                    </div>
                </div>
                {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
                <div className="mt-6 flex justify-end space-x-4">
                    <button onClick={onClose} className="px-4 py-2 rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300">Cancel</button>
                    <button onClick={handleSubmit} className="px-4 py-2 rounded-md text-white bg-green-600 hover:bg-green-700">Confirm</button>
                </div>
            </div>
        </div>
    );
};


const QuotationPage: React.FC = () => {
    const navigate = useNavigate();
    const { id: quotationId } = useParams();
    const location = useLocation();
    const { currentUser } = useContext(AuthContext);

    const [quotation, setQuotation] = useState<Partial<Quotation>>({
        products: [{ barcode: '', unit: 'MTR', quantity: 0, mrp: 0, total: 0 }],
        services: [],
        productDiscount: { percent: 0, amount: 0 },
        serviceDiscount: { percent: 0, amount: 0 },
    });
    
    const [salesmen, setSalesmen] = useState<Salesman[]>([]);
    const [serviceItems, setServiceItems] = useState<ServiceItem[]>([]);
    
    const [dateError, setDateError] = useState('');
    const [formError, setFormError] = useState('');
    
    const [isCancelModalOpen, setCancelModalOpen] = useState(false);
    const [isSaleModalOpen, setSaleModalOpen] = useState(false);
    const [showFeedback, setShowFeedback] = useState(false);
    const [feedbackStatus, setFeedbackStatus] = useState<QuotationStatus>(QuotationStatus.DRAFT);

    const loadData = useCallback(() => {
        if (!currentUser) return;

        // Master data is global now
        setSalesmen(storage.getCollection<Salesman>(SALESMEN_KEY));
        setServiceItems(storage.getCollection<ServiceItem>(SERVICE_ITEMS_KEY));

        if (quotationId && quotationId !== 'new') {
            const existingQuotation = storage.getDocument<Quotation>(QUOTATIONS_KEY, quotationId);
            if (existingQuotation) {
                // Security check: regular users can only edit their own quotations
                if (currentUser.isAdmin || existingQuotation.userId === currentUser.mobile) {
                    setQuotation(existingQuotation);
                } else {
                    setFormError("You do not have permission to view this quotation.");
                }
            }
        } else if (location.state?.customer) {
            setQuotation(q => ({ 
                ...q, 
                customerName: location.state.customer.name, 
                customerMobile: location.state.customer.mobile 
            }));
        }
    }, [quotationId, location.state, currentUser]);

    useEffect(() => {
        loadData();
    }, [loadData]);

    useEffect(() => {
        if (quotation.trialDate && quotation.deliveryDate && new Date(quotation.trialDate) >= new Date(quotation.deliveryDate)) {
            setDateError('Delivery Date must be after Trial Date');
        } else {
            setDateError('');
        }
    }, [quotation.trialDate, quotation.deliveryDate]);

    const handleItemChange = (
        index: number,
        field: string,
        value: any,
        itemType: 'product' | 'service'
    ) => {
        setQuotation(prev => {
            if (!prev) return prev;
            
            const newQuotation = { ...prev };

            if (itemType === 'product') {
                const products = [...(newQuotation.products || [])];
                const item = { ...products[index] } as QuotationItem;
                (item as any)[field] = value;
                item.total = (parseFloat(String(item.quantity)) || 0) * (parseFloat(String(item.mrp)) || 0);
                products[index] = item;
                newQuotation.products = products;
            } else { // service
                const services = [...(newQuotation.services || [])];
                const item = { ...services[index] } as StitchingItem;
                 (item as any)[field] = value;
                if (field === 'name') {
                    const selectedService = serviceItems.find(s => s.name === value);
                    item.mrp = selectedService ? selectedService.mrp : 0;
                }
                item.total = (parseFloat(String(item.quantity)) || 0) * (parseFloat(String(item.mrp)) || 0);
                services[index] = item;
                newQuotation.services = services;
            }
            return newQuotation;
        });
    };

    const handleDiscountChange = (type: 'product' | 'service', field: 'percent' | 'amount', value: string) => {
        const subtotal = type === 'product' 
            ? (quotation.products || []).reduce((acc, item) => acc + (item.total || 0), 0)
            : (quotation.services || []).reduce((acc, item) => acc + (item.total || 0), 0);
        
        let newPercent = 0;
        let newAmount = 0;
        const parsedValue = parseFloat(value) || 0;

        if (field === 'percent') {
            newPercent = parsedValue;
            newAmount = subtotal > 0 ? (subtotal * parsedValue) / 100 : 0;
        } else { // amount
            newAmount = parsedValue;
            newPercent = subtotal > 0 ? (parsedValue / subtotal) * 100 : 0;
        }
        const discount = { percent: newPercent, amount: newAmount };
        setQuotation(prev => {
            if (!prev) return prev;
            return type === 'product'
                ? { ...prev, productDiscount: discount }
                : { ...prev, serviceDiscount: discount };
        });
    };

    const productSubtotal = (quotation.products || []).reduce((acc, item) => acc + (item.total || 0), 0);
    const serviceSubtotal = (quotation.services || []).reduce((acc, item) => acc + (item.total || 0), 0);

    const productNetTotal = productSubtotal - (quotation.productDiscount?.amount || 0);
    const serviceNetTotal = serviceSubtotal - (quotation.serviceDiscount?.amount || 0);
    const grandTotal = Math.round(productNetTotal + serviceNetTotal);

    const addRow = (itemType: 'product' | 'service') => {
        setQuotation(prev => {
            if (!prev) return prev;
            if (itemType === 'product') {
                const newProduct: QuotationItem = { barcode: '', unit: 'MTR', quantity: 0, mrp: 0, total: 0 };
                const products = [...(prev.products || []), newProduct];
                return { ...prev, products };
            } else {
                const newService: StitchingItem = { name: '', unit: 'PCS', quantity: 0, mrp: 0, total: 0 };
                const services = [...(prev.services || []), newService];
                return { ...prev, services };
            }
        });
    };

    const removeRow = (index: number, itemType: 'product' | 'service') => {
        setQuotation(prev => {
            if (!prev) return prev;
            if (itemType === 'product') {
                const products = (prev.products || []).filter((_, i) => i !== index);
                return { ...prev, products };
            } else {
                const services = (prev.services || []).filter((_, i) => i !== index);
                return { ...prev, services };
            }
        });
    };

    const saveOrUpdateQuotation = (newStatus: QuotationStatus, details: { cancellationReason?: CancellationReason | null; saleDetails?: { billNumber: string; billDate: string; }; } = {}) => {
        if (!currentUser) {
            setFormError('You must be logged in to save a quotation.');
            return;
        }

        setFormError('');
        if (!quotation.trialDate || !quotation.deliveryDate || !quotation.salesman) {
            setFormError('Trial Date, Delivery Date, and Salesman are required.');
            return;
        }
        if (dateError) {
            setFormError(dateError); return;
        }
        if (!quotation.customerName || !quotation.customerMobile) {
            setFormError('Customer details are missing.'); return;
        }

        const isNewQuotation = !quotation.id || quotationId === 'new';

        const dataToSave: Omit<Quotation, 'id'> = {
            quotationNumber: quotation.quotationNumber || '', // Placeholder
            userId: quotation.userId || currentUser.mobile,
            customerName: quotation.customerName,
            customerMobile: quotation.customerMobile,
            trialDate: quotation.trialDate,
            deliveryDate: quotation.deliveryDate,
            salesman: quotation.salesman,
            products: quotation.products || [],
            services: quotation.services || [],
            productDiscount: quotation.productDiscount || { percent: 0, amount: 0 },
            serviceDiscount: quotation.serviceDiscount || { percent: 0, amount: 0 },
            productSubtotal,
            serviceSubtotal,
            grandTotal,
            status: newStatus,
            cancellationReason: details.cancellationReason || undefined,
            saleBillNumber: details.saleDetails?.billNumber,
            saleBillDate: details.saleDetails?.billDate,
            createdAt: quotation.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };

        try {
            if (isNewQuotation) {
                const allQuotations = storage.getCollection<Quotation>(QUOTATIONS_KEY);
                dataToSave.quotationNumber = generateNextQuotationNumber(currentUser.mobile, currentUser.name, allQuotations);
                const newDoc = storage.addDocument<Quotation>(QUOTATIONS_KEY, dataToSave);
                setQuotation(q => ({ ...q, id: newDoc.id, quotationNumber: dataToSave.quotationNumber }));
            } else {
                storage.updateDocument<Quotation>(QUOTATIONS_KEY, quotation.id!, dataToSave);
            }
            setFeedbackStatus(newStatus);
            setShowFeedback(true);
        } catch (error) {
            console.error("Error saving quotation:", error);
            setFormError('Failed to save quotation.');
        }
    };
    
    const handleClosePopup = useCallback(() => {
        setShowFeedback(false);
        navigate('/history');
    }, [navigate]);

    const handleConfirmSale = (saleDetails: { billNumber: string, billDate: string }) => {
        saveOrUpdateQuotation(QuotationStatus.SALE, { saleDetails });
        setSaleModalOpen(false);
    };

    const renderItemSection = (
        title: string,
        items: QuotationItem[] | StitchingItem[],
        itemType: 'product' | 'service'
    ) => {
        const subtotal = itemType === 'product' ? productSubtotal : serviceSubtotal;
        const discount = itemType === 'product' ? (quotation.productDiscount || { percent: 0, amount: 0 }) : (quotation.serviceDiscount || { percent: 0, amount: 0 });
        const netTotal = itemType === 'product' ? productNetTotal : serviceNetTotal;
        const discountType = itemType;

        return (
            <div className="space-y-3 p-4 border rounded-lg bg-white shadow-sm">
                <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-gray-700">{title}</h3>
                    <button onClick={() => addRow(itemType)} className="flex items-center space-x-2 text-sm font-medium text-brand-indigo-600 hover:text-brand-indigo-800 bg-brand-indigo-50 px-3 py-1.5 rounded-md transition-colors">
                        <PlusCircle size={14} /><span>Add Row</span>
                    </button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="hidden md:table-header-group bg-gray-50">
                            <tr>
                                <th className="w-10"></th>
                                <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-2/5">{itemType === 'product' ? 'Barcode/Product' : 'Stitching Service'}</th>
                                <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">Unit</th>
                                <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">Qty</th>
                                <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">MRP</th>
                                <th className="px-2 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-1/6">Total</th>
                            </tr>
                        </thead>
                        <tbody className="block md:table-row-group">
                            {(items as any[]).map((item, i) => (
                                <tr key={i} className="block md:table-row mb-4 md:mb-0 border md:border-b md:border-x-0 rounded-lg shadow-md md:shadow-none md:border-t-0">
                                    <td className="p-2 border-b md:border-0 md:w-10 md:p-0 md:table-cell md:text-center align-middle">
                                        <button onClick={() => removeRow(i, itemType)} className="text-red-500 hover:text-red-700 p-1 float-right md:float-none"><Trash2 size={16} /></button>
                                    </td>
                                    
                                    <td className="p-2 block md:table-cell align-middle">
                                        <div className="flex justify-between items-center md:block">
                                            <span className="font-bold md:hidden text-xs uppercase">{itemType === 'product' ? 'Barcode/Product' : 'Stitching Service'}</span>
                                            {itemType === 'product' ?
                                                <input type="text" value={(item as QuotationItem).barcode} onChange={e => handleItemChange(i, 'barcode', e.target.value, 'product')} className="w-3/5 md:w-full bg-transparent border-b border-gray-300 focus:outline-none focus:border-brand-indigo-500 p-1" />
                                                :
                                                <select value={(item as StitchingItem).name} onChange={e => handleItemChange(i, 'name', e.target.value, 'service')} className="w-3/5 md:w-full bg-transparent border-b border-gray-300 focus:outline-none focus:border-brand-indigo-500 p-1">
                                                    <option value="">Select Service</option>
                                                    {serviceItems.map(si => <option key={si.id} value={si.name}>{si.name}</option>)}
                                                </select>
                                            }
                                        </div>
                                    </td>

                                    <td className="p-2 block md:table-cell align-middle">
                                        <div className="flex justify-between items-center md:block">
                                            <span className="font-bold md:hidden text-xs uppercase">Unit</span>
                                            {itemType === 'product' ?
                                                <select value={item.unit} onChange={e => handleItemChange(i, 'unit', e.target.value, 'product')} className="w-3/5 md:w-full bg-transparent border-b border-gray-300 focus:outline-none focus:border-brand-indigo-500 p-1">
                                                    <option value="MTR">MTR</option>
                                                    <option value="PCS">PCS</option>
                                                </select>
                                                : <span className="p-1 block w-3/5 md:w-full text-right md:text-left">PCS</span>
                                            }
                                        </div>
                                    </td>
                                    
                                    <td className="p-2 block md:table-cell align-middle">
                                        <div className="flex justify-between items-center md:block">
                                            <span className="font-bold md:hidden text-xs uppercase">Qty</span>
                                            <input type="number" min="0" value={item.quantity} onChange={e => handleItemChange(i, 'quantity', e.target.value, itemType)} className="w-3/5 md:w-full text-right md:text-left bg-transparent border-b border-gray-300 focus:outline-none focus:border-brand-indigo-500 p-1" />
                                        </div>
                                    </td>
                                    
                                    <td className="p-2 block md:table-cell align-middle">
                                        <div className="flex justify-between items-center md:block">
                                            <span className="font-bold md:hidden text-xs uppercase">MRP</span>
                                            <input type="number" min="0" value={item.mrp} onChange={e => handleItemChange(i, 'mrp', e.target.value, itemType)} className="w-3/5 md:w-full text-right md:text-left bg-transparent border-b border-gray-300 focus:outline-none focus:border-brand-indigo-500 p-1" readOnly={itemType === 'service'} />
                                        </div>
                                    </td>

                                    <td className="p-2 block md:table-cell md:text-right align-middle">
                                        <div className="flex justify-between items-center md:block">
                                            <span className="font-bold md:hidden text-xs uppercase">Total</span>
                                            <span className="p-1 font-semibold">₹{item.total.toFixed(2)}</span>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <div className="flex justify-end pt-4">
                    <div className="w-full md:w-1/2 lg:w-2/5 space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-gray-600">Subtotal:</span><span className="font-medium">₹{subtotal.toFixed(2)}</span></div>
                        <div className="flex justify-between items-center">
                            <span className="text-gray-600">Discount:</span>
                            <div className="flex items-center space-x-2">
                                <input type="number" value={discount.percent} onChange={e => handleDiscountChange(discountType, 'percent', e.target.value)} className="w-20 border-gray-300 rounded-md p-1 text-sm focus:ring-brand-indigo-500 focus:border-brand-indigo-500" placeholder="%" />
                                <span>%</span>
                                <input type="number" value={discount.amount} onChange={e => handleDiscountChange(discountType, 'amount', e.target.value)} className="w-24 border-gray-300 rounded-md p-1 text-sm focus:ring-brand-indigo-500 focus:border-brand-indigo-500" placeholder="Amt" />
                                <span>₹</span>
                            </div>
                        </div>
                        <div className="flex justify-between font-bold border-t pt-2 mt-2"><span className="text-gray-800">Net Total:</span><span>₹{netTotal.toFixed(2)}</span></div>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="max-w-6xl mx-auto bg-brand-indigo-50 p-2 sm:p-6 rounded-xl space-y-6">
            {isCancelModalOpen && <CancelModal onSubmit={(reason) => { setCancelModalOpen(false); saveOrUpdateQuotation(QuotationStatus.CANCEL, { cancellationReason: reason }); }} onClose={() => setCancelModalOpen(false)} />}
            {isSaleModalOpen && <ConfirmSaleModal onClose={() => setSaleModalOpen(false)} onSubmit={handleConfirmSale} />}
            {showFeedback && <FeedbackPopup status={feedbackStatus} onClose={handleClosePopup} />}
            
            <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md border-b pb-4">
                <div className="flex justify-between items-start flex-wrap gap-4">
                    <div className="space-y-2">
                        <p className="font-bold text-lg text-gray-800"><span className="font-semibold text-gray-600">Customer:</span> {quotation.customerName}</p>
                        <p className="font-bold text-lg text-gray-800"><span className="font-semibold text-gray-600">Mobile:</span> {quotation.customerMobile}</p>
                    </div>
                    <div className="text-sm text-right space-y-3 w-full sm:w-auto">
                        <DateInput label="Trial Date" value={quotation.trialDate || ''} onChange={val => setQuotation(q => ({ ...q, trialDate: val }))} />
                        <DateInput label="Delivery Date" value={quotation.deliveryDate || ''} onChange={val => setQuotation(q => ({ ...q, deliveryDate: val }))} />
                         <div className="flex items-center justify-end">
                             <label className="text-sm font-semibold text-gray-700 mr-2">Salesman</label>
                            <div className="flex items-center">
                                <select value={quotation.salesman || ''} onChange={e => setQuotation(q => ({ ...q, salesman: e.target.value }))} className="block w-full border-gray-300 rounded-md shadow-sm text-sm p-1.5 focus:ring-brand-indigo-500 focus:border-brand-indigo-500">
                                    <option value="">Select Salesman</option>
                                    {salesmen.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                 {dateError && <p className="mt-2 text-xs text-red-600 text-center bg-red-100 p-2 rounded-md">{dateError}</p>}
                 {formError && <p className="mt-2 text-xs text-red-600 text-center bg-red-100 p-2 rounded-md">{formError}</p>}
            </div>

            {renderItemSection('Products', quotation.products || [], 'product')}
            {renderItemSection('Stitching / Services', quotation.services || [], 'service')}
            
            <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md border-t pt-4 space-y-4">
                <div className="text-right">
                    <span className="text-gray-600 font-medium text-lg">Grand Total</span>
                    <p className="text-3xl font-bold text-gray-800">₹{grandTotal.toFixed(2)}</p>
                </div>
                <div className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3">
                    <button onClick={() => saveOrUpdateQuotation(QuotationStatus.DRAFT)} className="py-2 px-6 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">Save as Draft</button>
                    <button onClick={() => setCancelModalOpen(true)} className="py-2 px-6 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 transition-colors">Cancel</button>
                    <button onClick={() => setSaleModalOpen(true)} className="py-2 px-6 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 transition-colors">Confirm Sale</button>
                </div>
            </div>
        </div>
    );
};

export default QuotationPage;