
import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { Customer, Quotation, QuotationStatus } from '../types';
import * as storage from '../services/storageService';
import { QUOTATIONS_KEY } from '../constants';
import { FeedbackPopup, CancelModal } from '../components/SharedComponents';
import { AuthContext } from '../auth/AuthContext';

const getUserInitials = (name: string): string => {
    if (!name) return 'NA';
    const parts = name.trim().split(/\s+/);
    if (parts.length > 1) {
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    if (parts[0].length >= 2) {
        return parts[0].substring(0, 2).toUpperCase();
    }
    return parts[0].toUpperCase();
};

const generateNextQuotationNumber = (userId: string, userName:string, allQuotations: Quotation[]): string => {
    const userQuotations = allQuotations.filter(q => q.userId === userId && q.quotationNumber);
    let maxNum = 0;
    userQuotations.forEach(q => {
        const parts = q.quotationNumber.split('/');
        if (parts.length === 2) {
            const num = parseInt(parts[1], 10);
            if (!isNaN(num) && num > maxNum) {
                maxNum = num;
            }
        }
    });
    const nextNum = maxNum + 1;
    const paddedNum = String(nextNum).padStart(3, '0');
    const initials = getUserInitials(userName);
    return `${initials}/${paddedNum}`;
}

const NewQuotationForm: React.FC = () => {
    const navigate = useNavigate();
    const { currentUser } = useContext(AuthContext);

    const [name, setName] = useState('');
    const [mobile, setMobile] = useState('');
    const [error, setError] = useState('');
    const [isCancelModalOpen, setCancelModalOpen] = useState(false);
    
    const [allCustomers, setAllCustomers] = useState<Customer[]>([]);
    const [searchResults, setSearchResults] = useState<Customer[]>([]);
    const [showResults, setShowResults] = useState(false);
    const [showFeedback, setShowFeedback] = useState(false);

    useEffect(() => {
        const allQuotations = storage.getCollection<Quotation>(QUOTATIONS_KEY);
        const customerMap = new Map<string, Customer>();
        allQuotations.forEach(q => {
            if (q.customerMobile && q.customerName) {
                customerMap.set(q.customerMobile, { name: q.customerName, mobile: q.customerMobile });
            }
        });
        setAllCustomers(Array.from(customerMap.values()));
    }, [currentUser]);

    const handleSearch = (value: string, field: 'name' | 'mobile') => {
        let currentName = field === 'name' ? value : name;
        let currentMobile = field === 'mobile' ? value.replace(/\D/g, '') : mobile;
        
        if (currentMobile.length > 10) return;

        setName(currentName);
        setMobile(currentMobile);

        if (currentName.trim().length > 0 || currentMobile.length > 0) {
            const results = allCustomers.filter(c => 
                c.name.toLowerCase().includes(currentName.toLowerCase()) && c.mobile.includes(currentMobile)
            );
            setSearchResults(results);
            setShowResults(true);
        } else {
            setShowResults(false);
        }
    };

    const selectCustomer = (customer: Customer) => {
        setName(customer.name);
        setMobile(customer.mobile);
        setShowResults(false);
    };
    
    const handleCreate = () => {
        setError('');
        if (!name.trim()) { 
            setError("Customer name cannot be empty.");
            return; 
        }
        if (!/^\d{10}$/.test(mobile)) { 
            setError('Mobile number must be 10 digits.'); 
            return; 
        }
        navigate('/quotation/new', { state: { customer: { name, mobile } } });
    };

    const handleCancelSubmit = (reason: { category: string; subCategory: string }) => {
        if (!currentUser) return;

        const allQuotations = storage.getCollection<Quotation>(QUOTATIONS_KEY);
        const newQuotationNumber = generateNextQuotationNumber(currentUser.mobile, currentUser.name, allQuotations);

        storage.addDocument<Quotation>(QUOTATIONS_KEY, {
            quotationNumber: newQuotationNumber,
            userId: currentUser.mobile,
            customerName: name || 'N/A', customerMobile: mobile || 'N/A',
            status: QuotationStatus.WALK_OUT,
            cancellationReason: reason,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            trialDate: '', deliveryDate: '', salesman: '', products: [], services: [],
            productDiscount: { percent: 0, amount: 0 }, serviceDiscount: { percent: 0, amount: 0 },
            productSubtotal: 0, serviceSubtotal: 0, grandTotal: 0,
        });
        setCancelModalOpen(false);
        setShowFeedback(true);
    };

    const resetForm = () => {
        setName('');
        setMobile('');
        setError('');
        setShowFeedback(false);
    };

    return (
         <div className="max-w-lg mx-auto">
            {showFeedback && <FeedbackPopup status={QuotationStatus.WALK_OUT} onClose={resetForm} />}
            <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg">
                <div className="space-y-6">
                    <h2 className="text-2xl font-bold text-center text-brand-indigo-800">New Quotation</h2>
                    <div className="relative">
                        <label htmlFor="customerName" className="text-sm font-medium text-gray-700">Customer Name</label>
                        <input id="customerName" type="text" value={name} onChange={(e) => handleSearch(e.target.value, 'name')} placeholder="Search or enter name" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-brand-indigo-500" />
                         {showResults && searchResults.length > 0 && (
                            <ul className="absolute z-10 w-full bg-white border border-gray-300 rounded-md mt-1 max-h-40 overflow-y-auto shadow-lg">
                                {searchResults.map((c, i) => (
                                    <li key={i} onClick={() => selectCustomer(c)} className="px-3 py-2 cursor-pointer hover:bg-brand-indigo-50">{c.name} - {c.mobile}</li>
                                ))}
                            </ul>
                        )}
                    </div>
                    <div>
                        <label htmlFor="mobileNumber" className="text-sm font-medium text-gray-700">Mobile Number</label>
                        <div className="relative">
                            <input id="mobileNumber" type="tel" value={mobile} onChange={(e) => handleSearch(e.target.value, 'mobile')} placeholder="Search or enter 10-digit mobile" className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-1 ${error ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-brand-indigo-500'}`} />
                        </div>
                        {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
                    </div>
                    <div className="flex flex-col sm:flex-row sm:space-x-4 space-y-3 sm:space-y-0 pt-2">
                        <button onClick={handleCreate} className="w-full flex-1 inline-flex justify-center py-3 px-4 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-brand-indigo-700 hover:bg-brand-indigo-800 transition-transform transform hover:scale-105">Create Quotation</button>
                        <button onClick={() => setCancelModalOpen(true)} className="w-full flex-1 inline-flex justify-center py-3 px-4 border border-gray-300 shadow-sm text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transition-transform transform hover:scale-105">Customer Walk-out</button>
                    </div>
                </div>
            </div>
            {isCancelModalOpen && <CancelModal onClose={() => setCancelModalOpen(false)} onSubmit={handleCancelSubmit} />}
        </div>
    );
}

const HomePage: React.FC = () => {
    return (
        <div className="max-w-7xl mx-auto mt-2">
            <NewQuotationForm />
        </div>
    );
};


export default HomePage;