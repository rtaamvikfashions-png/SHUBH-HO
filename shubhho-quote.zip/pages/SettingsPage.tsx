

import React, { useState, useEffect, useContext } from 'react';
import { useLocation } from 'react-router-dom';
import { Plus, Edit, Save, Trash2, X } from 'lucide-react';
import * as storage from '../services/storageService';
import { SALESMEN_KEY, SERVICE_ITEMS_KEY, PRODUCTS_KEY, USERS_KEY, SECRET_QUESTIONS } from '../constants';
import { Salesman, ServiceItem, ProductItem, User } from '../types';
import { ConfirmationDialog, PasswordInput } from '../components/SharedComponents';
import { AuthContext } from '../auth/AuthContext';

const ChangePasswordForm: React.FC = () => {
    const { changePassword } = useContext(AuthContext);
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (newPassword.length < 6) {
            setError('New password must be at least 6 characters long.');
            return;
        }
        if (newPassword !== confirmPassword) {
            setError('New passwords do not match.');
            return;
        }

        setLoading(true);
        const result = await changePassword(currentPassword, newPassword);
        setLoading(false);

        if (result.success) {
            setSuccess(result.message);
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
        } else {
            setError(result.message);
        }
    };

    return (
        <div className="max-w-lg">
            <h3 className="text-lg font-bold text-gray-700 mb-4">Change Password</h3>
            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
                <div>
                    <label className="text-sm font-medium text-gray-700">Current Password</label>
                    <PasswordInput value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} required className="mt-1"/>
                </div>
                <div>
                    <label className="text-sm font-medium text-gray-700">New Password</label>
                    <PasswordInput value={newPassword} onChange={e => setNewPassword(e.target.value)} required className="mt-1" placeholder="At least 6 characters"/>
                </div>
                <div>
                    <label className="text-sm font-medium text-gray-700">Confirm New Password</label>
                    <PasswordInput value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required className="mt-1"/>
                </div>
                {error && <p className="text-sm text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}
                {success && <p className="text-sm text-green-600 bg-green-100 p-3 rounded-md">{success}</p>}
                <div>
                    <button type="submit" disabled={loading} className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-indigo-600 hover:bg-brand-indigo-700 disabled:bg-brand-indigo-400">
                        {loading ? 'Updating...' : 'Update Password'}
                    </button>
                </div>
            </form>
        </div>
    );
};

const SecretQuestionForm: React.FC = () => {
    const { currentUser, updateUserProfile } = useContext(AuthContext);
    const [secretQuestion, setSecretQuestion] = useState('');
    const [secretAnswer, setSecretAnswer] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (currentUser) {
            setSecretQuestion(currentUser.secretQuestion || SECRET_QUESTIONS[0]);
        }
    }, [currentUser]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        if (!secretQuestion || !secretAnswer) {
            setError('Both secret question and answer are required.');
            return;
        }
        if (!currentUser) return;

        setLoading(true);
        const result = await updateUserProfile(currentUser.id, { secretQuestion, secretAnswer });
        setLoading(false);

        if (result.success) {
            setSuccess(result.message);
            setSecretAnswer('');
        } else {
            setError(result.message);
        }
    };
    
    if(!currentUser) return null;

    return (
         <div className="max-w-lg mt-8 border-t pt-8">
            <h3 className="text-lg font-bold text-gray-700 mb-4">Password Recovery Question</h3>
            <p className="text-sm text-gray-600 mb-4">Set a secret question and answer to recover your password if you forget it.</p>
            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
                 <div>
                    <label className="text-sm font-medium text-gray-700">Secret Question</label>
                    <select value={secretQuestion} onChange={e => setSecretQuestion(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-indigo-500 focus:border-brand-indigo-500">
                        {SECRET_QUESTIONS.map(q => <option key={q} value={q}>{q}</option>)}
                    </select>
                </div>
                <div>
                    <label className="text-sm font-medium text-gray-700">Your Secret Answer</label>
                    <PasswordInput value={secretAnswer} onChange={e => setSecretAnswer(e.target.value)} required className="mt-1" placeholder="Case-insensitive"/>
                </div>
                {error && <p className="text-sm text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}
                {success && <p className="text-sm text-green-600 bg-green-100 p-3 rounded-md">{success}</p>}
                <div>
                    <button type="submit" disabled={loading} className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-indigo-600 hover:bg-brand-indigo-700 disabled:bg-brand-indigo-400">
                        {loading ? 'Saving...' : 'Save Secret Question'}
                    </button>
                </div>
            </form>
        </div>
    );
};

const ProfileManagement: React.FC = () => {
    return (
        <div>
            <ChangePasswordForm />
            <SecretQuestionForm />
        </div>
    );
};

const EditUserModal: React.FC<{ user: User; onClose: () => void; onUpdate: () => void; }> = ({ user, onClose, onUpdate }) => {
    const { updateUserProfile } = useContext(AuthContext);
    const [name, setName] = useState(user.name);
    const [newPassword, setNewPassword] = useState('');
    const [isAdmin, setIsAdmin] = useState(user.isAdmin);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [loading, setLoading] = useState(false);

    const handleUpdate = async () => {
        setError('');
        setSuccess('');

        if (!name.trim()) {
            setError("User name cannot be empty.");
            return;
        }

        const dataToUpdate: Partial<User> & { password?: string } = { name, isAdmin };
        if (newPassword) {
            if (newPassword.length < 6) {
                setError("New password must be at least 6 characters.");
                return;
            }
            dataToUpdate.password = newPassword;
        }

        setLoading(true);
        const result = await updateUserProfile(user.id, dataToUpdate);
        setLoading(false);

        if (result.success) {
            setSuccess(result.message);
            onUpdate();
            setTimeout(onClose, 1500);
        } else {
            setError(result.message);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
            <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md relative">
                <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-gray-600"><X size={24} /></button>
                <h3 className="text-lg font-bold text-gray-800">Edit User: {user.mobile}</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label className="text-sm font-medium text-gray-700">Full Name</label>
                        <input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"/>
                    </div>
                     <div>
                        <label className="text-sm font-medium text-gray-700">Reset Password (optional)</label>
                        <PasswordInput value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Leave blank to keep current password" className="mt-1"/>
                    </div>
                    <div className="flex items-center">
                        <input type="checkbox" id="editIsAdmin" checked={isAdmin} onChange={e => setIsAdmin(e.target.checked)} disabled={user.mobile === 'admin'} className="h-4 w-4 rounded border-gray-300 text-brand-indigo-600"/>
                        <label htmlFor="editIsAdmin" className="ml-2 text-sm text-gray-700">Is Admin</label>
                    </div>
                </div>
                {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
                {success && <p className="mt-2 text-sm text-green-600">{success}</p>}
                <div className="mt-6 flex justify-end space-x-4">
                    <button onClick={onClose} className="px-4 py-2 rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300">Cancel</button>
                    <button onClick={handleUpdate} disabled={loading} className="px-4 py-2 rounded-md text-white bg-brand-indigo-600 hover:bg-brand-indigo-700 disabled:bg-brand-indigo-400">
                        {loading ? 'Saving...' : 'Save Changes'}
                    </button>
                </div>
            </div>
        </div>
    );
};


const UserManagement: React.FC = () => {
    const { createUser } = useContext(AuthContext);
    const [users, setUsers] = useState<User[]>([]);
    const [name, setName] = useState('');
    const [mobile, setMobile] = useState('');
    const [password, setPassword] = useState('');
    const [isAdmin, setIsAdmin] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [loading, setLoading] = useState(false);
    const [selected, setSelected] = useState<string[]>([]);
    const [isDeleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<User | null>(null);

    const loadUsers = () => setUsers(storage.getCollection<User>(USERS_KEY));

    useEffect(() => {
        loadUsers();
    }, []);

    const handleCreateUser = async () => {
        setError('');
        setSuccess('');
        if (!name.trim()) {
            setError('Full name is required.');
            return;
        }
        if (!/^\d{10}$/.test(mobile) && mobile !== 'admin') {
            setError('Mobile number must be 10 digits.');
            return;
        }
        if (password.length < 6) {
            setError('Password must be at least 6 characters.');
            return;
        }
        setLoading(true);
        const result = await createUser(name, mobile, password, isAdmin);
        setLoading(false);
        if (result.success) {
            setSuccess(result.message);
            setName('');
            setMobile('');
            setPassword('');
            setIsAdmin(false);
            loadUsers();
        } else {
            setError(result.message);
        }
    };
    
    const handleDelete = () => {
        const undeletable = users.filter(u => selected.includes(u.id) && u.mobile === 'admin');
        if (undeletable.length > 0) {
            alert(`The default admin user (${undeletable.map(u => u.name).join(', ')}) cannot be deleted.`);
            setDeleteConfirmOpen(false);
            return;
        }
        storage.deleteDocuments(USERS_KEY, selected);
        setSelected([]);
        loadUsers();
        setDeleteConfirmOpen(false);
    };

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            setSelected(users.map(i => i.id));
        } else {
            setSelected([]);
        }
    };

    return (
        <div>
            {editingUser && <EditUserModal user={editingUser} onClose={() => setEditingUser(null)} onUpdate={loadUsers} />}
            <ConfirmationDialog 
                isOpen={isDeleteConfirmOpen} 
                onClose={() => setDeleteConfirmOpen(false)}
                onConfirm={handleDelete}
                title="Confirm Deletion"
                message={`Are you sure you want to delete ${selected.length} user(s)? This action cannot be undone.`}
            />
            <div className="space-y-4">
                <div className="p-4 border rounded-lg bg-gray-50 shadow-sm">
                    <h3 className="text-md font-bold text-gray-700 mb-2">Create New User</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 items-end">
                        <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Full Name" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"/>
                        <input type="text" value={mobile} onChange={e => setMobile(e.target.value)} placeholder="10-digit Mobile" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"/>
                        <PasswordInput value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" className="mt-1"/>
                        <div className="flex items-center">
                            <input type="checkbox" id="isAdmin" checked={isAdmin} onChange={e => setIsAdmin(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-brand-indigo-600"/>
                            <label htmlFor="isAdmin" className="ml-2 text-sm text-gray-700">Is Admin?</label>
                        </div>
                        <button onClick={handleCreateUser} disabled={loading} className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-indigo-600 hover:bg-brand-indigo-700 disabled:bg-brand-indigo-400">Create User</button>
                    </div>
                    {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
                    {success && <p className="text-sm text-green-600 mt-2">{success}</p>}
                </div>
                
                <div className="mt-6 overflow-x-auto">
                  <div className="flex justify-end mb-4">
                      {selected.length > 0 && <button onClick={() => setDeleteConfirmOpen(true)} className="px-3 py-1 text-sm text-white bg-red-600 rounded-md hover:bg-red-700">Delete Selected ({selected.length})</button>}
                  </div>
                  <table className="min-w-full divide-y divide-gray-200 text-sm">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="p-2 w-12"><input type="checkbox" onChange={handleSelectAll} /></th>
                                <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase">Mobile / Username</th>
                                <th className="hidden sm:table-cell px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                                <th className="px-2 py-2 text-center text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {users.map(user => (
                                <tr key={user.id} className={selected.includes(user.id) ? 'bg-blue-50' : ''}>
                                    <td className="p-2 w-12"><input type="checkbox" checked={selected.includes(user.id)} onChange={() => setSelected(p => p.includes(user.id) ? p.filter(i => i !== user.id) : [...p, user.id])} /></td>
                                    <td className="px-2 py-2 font-medium">{user.name}</td>
                                    <td className="px-2 py-2">{user.mobile}</td>
                                    <td className="hidden sm:table-cell px-2 py-2">{user.isAdmin ? 'Admin' : 'User'}</td>
                                    <td className="px-2 py-2 text-center space-x-2">
                                        <button onClick={() => setEditingUser(user)} className="p-1 text-blue-600 hover:text-blue-800"><Edit size={16}/></button>
                                        {user.mobile !== 'admin' && <button onClick={() => { setSelected([user.id]); setDeleteConfirmOpen(true); }} className="p-1 text-red-600 hover:text-red-800"><Trash2 size={16}/></button>}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                  </table>
                </div>
            </div>
        </div>
    );
};


interface FieldConfig<T> { name: keyof T, type: string, placeholder: string }
interface EditableListProps<T extends {id: string, name: string, mrp?: number}> {
    collectionName: string;
    fields: FieldConfig<T>[];
    itemTitle: string;
}

const EditableList = <T extends {id: string, name: string, mrp?: number}>({ collectionName, fields, itemTitle }: EditableListProps<T>) => {
    const [items, setItems] = useState<T[]>([]);
    
    const getInitialState = () => fields.reduce((acc, f) => ({ ...acc, [f.name]: f.type === 'number' ? undefined : '' }), {}) as Partial<T>;

    const [newItem, setNewItem] = useState<Partial<T>>(getInitialState());
    const [editingId, setEditingId] = useState<string | null>(null);
    const [editingItem, setEditingItem] = useState<Partial<T> | null>(null);
    const [error, setError] = useState('');
    const [showAddForm, setShowAddForm] = useState(false);

    useEffect(() => {
        setItems(storage.getCollection<T>(collectionName));
    }, [collectionName]);

    const handleAddItem = () => {
        setError('');
        const isInvalid = fields.some(field => {
            const value = newItem[field.name];
            if (field.type === 'number') {
                return value == null || isNaN(value as number);
            }
            return !value;
        });

        if (isInvalid) {
            setError(`All fields for the new ${itemTitle} are required.`);
            return;
        }
        
        const addedItem = storage.addDocument(collectionName, newItem as Omit<T, 'id'>);
        setItems(prev => [...prev, addedItem as T]);
        setNewItem(getInitialState());
        setShowAddForm(false);
    };

    const handleUpdateItem = () => {
        if (!editingId || !editingItem) return;
        const { id, ...dataToUpdate } = editingItem;
        storage.updateDocument(collectionName, editingId, dataToUpdate);
        setItems(items.map(i => i.id === editingId ? { ...i, ...dataToUpdate } as T : i));
        setEditingId(null);
        setEditingItem(null);
    };
    
    const handleDeleteItem = (id: string) => {
        storage.deleteDocuments(collectionName, [id]);
        setItems(items.filter(i => i.id !== id));
    };

    const handleItemInputChange = (
        setter: React.Dispatch<React.SetStateAction<Partial<T> | null>>, 
        fieldName: keyof T,
        fieldType: string,
        value: string
    ) => {
        setter(prev => ({
            ...prev,
            [fieldName]: fieldType === 'number' 
                ? (value === '' ? undefined : parseFloat(value)) 
                : value
        }));
    };

    return (
        <div>
            <div className="flex justify-end mb-4">
                <button onClick={() => setShowAddForm(!showAddForm)} className="flex items-center space-x-2 text-sm font-medium text-white bg-brand-indigo-600 hover:bg-brand-indigo-700 px-3 py-1.5 rounded-md">
                    <Plus size={16}/><span>Add New {itemTitle}</span>
                </button>
            </div>
            {showAddForm && (
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 mb-4 p-3 bg-gray-50 rounded-lg border">
                    {fields.map(f => (
                        <input key={String(f.name)} type={f.type} value={(newItem?.[f.name] as any) ?? ''} 
                               onChange={e => handleItemInputChange(setNewItem as any, f.name, f.type, e.target.value)} 
                               placeholder={f.placeholder} className="flex-grow p-1 border-b focus:outline-none focus:border-brand-indigo-500 text-sm w-full"/>
                    ))}
                    <div className="flex justify-end gap-2">
                        <button onClick={handleAddItem} className="p-1 text-green-600 hover:text-green-800"><Save size={18}/></button>
                        <button onClick={() => setShowAddForm(false)} className="p-1 text-red-600 hover:text-red-800"><X size={18}/></button>
                    </div>
                    {error && <p className="text-xs text-red-500 self-center col-span-full">{error}</p>}
                </div>
            )}
            <div className="space-y-2">
                <div className="hidden sm:flex items-center p-2 bg-gray-100 rounded-t-lg font-bold text-sm text-gray-600">
                    <div className="flex-grow pl-4">{fields[0].placeholder}</div>
                    {fields.length > 1 && <div className="w-24">{fields[1].placeholder}</div>}
                    <div className="w-24 text-center">Actions</div>
                </div>
                {items.map((item) => (
                     <div key={item.id} className="block sm:flex sm:items-center p-2 bg-white border rounded-lg shadow-sm">
                        {editingId === item.id ? (
                            <div className="flex-grow space-y-2 sm:space-y-0 sm:flex sm:items-center sm:gap-2">
                                {fields.map(f => (
                                     <div key={String(f.name)} className="flex-grow sm:flex-none">
                                         <span className="text-xs font-bold uppercase text-gray-500 sm:hidden">{f.placeholder}</span>
                                         <input type={f.type} value={(editingItem?.[f.name] as any) ?? ''}
                                               onChange={e => handleItemInputChange(setEditingItem, f.name, f.type, e.target.value)}
                                               placeholder={f.placeholder} className={`w-full p-1 border-b focus:outline-none ${f.name === 'mrp' ? 'sm:w-24' : 'sm:flex-grow'}`} />
                                     </div>
                                ))}
                            </div>
                        ) : (
                            <div className="flex-grow sm:flex sm:items-center">
                                <div className="flex-grow sm:pl-4 text-sm font-medium">{item.name}</div>
                                {fields.length > 1 && <div className="sm:w-24 text-sm text-gray-600">
                                    <span className="sm:hidden font-bold">MRP: </span>
                                    ₹{item.mrp?.toFixed(2)}
                                    </div>
                                }
                            </div>
                        )}
                        <div className="w-full sm:w-24 flex items-center justify-end sm:justify-center space-x-2 mt-2 sm:mt-0 pt-2 sm:pt-0 border-t sm:border-t-0">
                            {editingId === item.id ? (
                                <>
                                    <button onClick={handleUpdateItem} className="p-1 text-green-600 hover:text-green-800"><Save size={16}/></button>
                                    <button onClick={() => setEditingId(null)} className="p-1 text-gray-500 hover:text-gray-700"><X size={16}/></button>
                                </>
                            ) : (
                                <button onClick={() => { setEditingId(item.id); setEditingItem(item); }} className="p-1 text-blue-600 hover:text-blue-800"><Edit size={16}/></button>
                            )}
                            <button onClick={() => handleDeleteItem(item.id)} className="p-1 text-red-600 hover:text-red-800"><Trash2 size={16}/></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};


const SettingsPage: React.FC = () => {
    const { currentUser } = useContext(AuthContext);
    const location = useLocation();

    const adminTabs = [
        { name: 'profile', label: 'Profile', component: <ProfileManagement /> },
        { name: 'users', label: 'Users', component: <UserManagement /> },
        { name: 'salesmen', label: 'Salesmen', component: <EditableList<Salesman> collectionName={SALESMEN_KEY} fields={[{name: 'name', type: 'text', placeholder: 'Salesman Name'}]} itemTitle="Salesman" /> },
        { name: 'services', label: 'Services', component: <EditableList<ServiceItem> collectionName={SERVICE_ITEMS_KEY} fields={[{name: 'name', type: 'text', placeholder: 'Service Name'}, {name: 'mrp', type: 'number', placeholder: 'MRP'}]} itemTitle="Service"/> },
    ];

    const userTabs = [
        { name: 'profile', label: 'Profile', component: <ProfileManagement /> },
    ];

    const tabs = currentUser?.isAdmin ? adminTabs : userTabs;
    
    const getInitialTab = () => {
        const requestedTab = location.state?.tab;
        // Ensure the requested tab is valid for the current user type
        if (requestedTab && tabs.some(t => t.name === requestedTab)) {
            return requestedTab;
        }
        return tabs[0].name;
    };

    const [activeTab, setActiveTab] = useState(getInitialTab());
    
    useEffect(() => {
        const requestedTab = location.state?.tab;
        if (requestedTab && tabs.some(t => t.name === requestedTab)) {
          setActiveTab(requestedTab);
        }
    }, [location.state, tabs]);


    return (
        <div className="max-w-6xl mx-auto bg-white p-2 sm:p-6 rounded-xl shadow-lg mt-8">
            <div className="border-b border-gray-200">
                <nav className="-mb-px flex space-x-2 sm:space-x-6 overflow-x-auto">
                    {tabs.map(tab => (
                        <button key={tab.name} onClick={() => setActiveTab(tab.name)}
                                className={`whitespace-nowrap py-3 px-4 text-sm font-medium transition-colors duration-200 ${activeTab === tab.name 
                                    ? 'border-b-2 border-brand-indigo-600 text-brand-indigo-600' 
                                    : 'border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                            {tab.label}
                        </button>
                    ))}
                </nav>
            </div>
            <div className="mt-6">
                {tabs.find(tab => tab.name === activeTab)?.component}
            </div>
        </div>
    );
};

export default SettingsPage;