import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';
import * as storage from '../services/storageService';
import { USERS_KEY, SECRET_QUESTIONS } from '../constants';
import { hashPassword } from './hash';

interface AuthContextType {
    currentUser: User | null;
    login: (mobile: string, password: string) => Promise<boolean>;
    createUser: (name: string, mobile: string, password: string, isAdmin: boolean) => Promise<{success: boolean, message: string}>;
    updateUserProfile: (userId: string, data: Partial<User> & { password?: string; secretAnswer?: string }) => Promise<{success: boolean, message: string}>;
    logout: () => void;
    changePassword: (currentPassword: string, newPassword: string) => Promise<{success: boolean, message: string}>;
    isLoading: boolean;
}

export const AuthContext = createContext<AuthContextType>({
    currentUser: null,
    login: async () => false,
    createUser: async () => ({success: false, message: 'Creation failed'}),
    updateUserProfile: async () => ({success: false, message: 'Update failed'}),
    logout: () => {},
    changePassword: async () => ({success: false, message: 'Password change failed'}),
    isLoading: true,
});

const SESSION_STORAGE_KEY = 'currentUser';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const bootstrap = async () => {
            try {
                const users = storage.getCollection<User>(USERS_KEY);
                if (users.length === 0) {
                    console.log("No users found. Creating default admin account.");
                    const passwordHash = await hashPassword('admin');
                    const secretAnswerHash = await hashPassword('admin');
                    const adminUser: Omit<User, 'id'> = {
                        name: 'Administrator',
                        mobile: 'admin',
                        passwordHash,
                        isAdmin: true,
                        secretQuestion: SECRET_QUESTIONS[0],
                        secretAnswerHash,
                    };
                    storage.addDocument<User>(USERS_KEY, adminUser);
                    console.log("Default admin 'admin' with password 'admin' created.");
                }

                const storedUser = window.sessionStorage.getItem(SESSION_STORAGE_KEY);
                if (storedUser) {
                    setCurrentUser(JSON.parse(storedUser));
                }
            } catch (e) {
                console.error("Bootstrap error:", e);
            }
            setIsLoading(false);
        };
        bootstrap();
    }, []);

    const login = async (mobile: string, password: string): Promise<boolean> => {
        const users = storage.getCollection<User>(USERS_KEY);
        const user = users.find(u => u.mobile === mobile);
        if (!user) {
            return false;
        }

        const passwordHash = await hashPassword(password);
        if (user.passwordHash === passwordHash) {
            setCurrentUser(user);
            window.sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(user));
            return true;
        }

        return false;
    };

    const createUser = async (name: string, mobile: string, password: string, isAdmin: boolean): Promise<{success: boolean, message: string}> => {
        const users = storage.getCollection<User>(USERS_KEY);
        if (users.some(u => u.mobile === mobile)) {
            return {success: false, message: 'A user with this mobile number already exists.'};
        }

        const passwordHash = await hashPassword(password);
        const secretAnswerHash = await hashPassword('default');
        
        const newUser: Omit<User, 'id'> = {
            name,
            mobile,
            passwordHash,
            isAdmin,
            secretQuestion: SECRET_QUESTIONS[0],
            secretAnswerHash,
        };
        
        storage.addDocument<User>(USERS_KEY, newUser);
        return {success: true, message: 'User created successfully!'};
    };

    const logout = () => {
        setCurrentUser(null);
        window.sessionStorage.removeItem(SESSION_STORAGE_KEY);
    };

    const changePassword = async (currentPassword: string, newPassword: string): Promise<{success: boolean, message: string}> => {
        if (!currentUser) {
            return { success: false, message: 'No user logged in.' };
        }
        
        const user = storage.getDocument<User>(USERS_KEY, currentUser.id);

        if (!user) {
            return { success: false, message: 'Could not find current user data.' };
        }

        const currentPasswordHash = await hashPassword(currentPassword);
        if (user.passwordHash !== currentPasswordHash) {
            return { success: false, message: 'Current password is incorrect.' };
        }

        const newPasswordHash = await hashPassword(newPassword);
        storage.updateDocument<User>(USERS_KEY, user.id, { passwordHash: newPasswordHash });

        return { success: true, message: 'Password updated successfully!' };
    };

    const updateUserProfile = async (userId: string, data: Partial<User> & { password?: string, secretAnswer?: string }): Promise<{success: boolean, message: string}> => {
        try {
            const dataToUpdate: Partial<Omit<User, 'id'>> = { ...data };
            
            if (data.password) {
                dataToUpdate.passwordHash = await hashPassword(data.password);
                delete (dataToUpdate as any).password;
            }

            if (data.secretAnswer) {
                dataToUpdate.secretAnswerHash = await hashPassword(data.secretAnswer.toLowerCase().trim());
                delete (dataToUpdate as any).secretAnswer;
            }

            storage.updateDocument<User>(USERS_KEY, userId, dataToUpdate);
            
            // If the currently logged-in user is being updated, refresh their session data
            if (currentUser && currentUser.id === userId) {
                const updatedUser = storage.getDocument<User>(USERS_KEY, userId);
                if(updatedUser) {
                    setCurrentUser(updatedUser);
                    window.sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(updatedUser));
                }
            }

            return { success: true, message: "Profile updated successfully!" };

        } catch (error) {
            const message = error instanceof Error ? error.message : 'An unknown error occurred';
            console.error("Error updating user profile", error);
            return { success: false, message: `Failed to update profile: ${message}` };
        }
    };

    return (
        <AuthContext.Provider value={{ currentUser, login, createUser, logout, changePassword, isLoading, updateUserProfile }}>
            {children}
        </AuthContext.Provider>
    );
};